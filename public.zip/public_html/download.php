<?php
session_write_close();
header('location: ' . strtr($_SERVER['REQUEST_URI'], ['download.php' => 'download/']) . '?' . $_SERVER['QUERY_STRING']);
