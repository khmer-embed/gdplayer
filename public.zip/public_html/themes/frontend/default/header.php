<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

$urlParser = parse_url(BASE_URL);
header("Access-Control-Allow-Origin: {$urlParser['scheme']}://{$urlParser['host']}");
header('Access-Control-Allow-Credentials: true');

$html = new \GDPlayer\HTML();
$plugins = new \GDPlayer\Plugins();
$userLogin = current_user();
$isAdmin = $userLogin && intval($userLogin['role']) === 0;

$themeColor = get_option('pwa_themecolor');
$rgbColor = hex2RGB($themeColor, true, ',');
$rgbColor = $rgbColor ? $rgbColor : '103, 58, 183';
$themeColor = !empty($themeColor) ? '#' . $themeColor : '#673ab7';

$customColor = get_option('custom_color');
$customColor = !empty($customColor) ? '#' . $customColor : '#673ab7';

$customColor2 = get_option('custom_color2');
$customColor2 = !empty($customColor2) ? '#' . $customColor2 : '#3f51b5';

ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <base href="<?php echo BASE_URL; ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="msapplication-TileColor" content="<?php echo $themeColor; ?>">
    <meta name="theme-color" content="<?php echo $themeColor; ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <meta name="description" content="<?php echo get_env('description'); ?>">

    <!-- facebook -->
    <meta name="og:sitename" content="<?php echo get_env('site_name'); ?>">
    <meta name="og:title" content="<?php echo get_env('title'); ?>">
    <meta name="og:description" content="<?php echo get_env('description'); ?>">
    <meta name="og:type" content="<?php echo get_env('page_type'); ?>">
    <meta name="og:image" content="<?php echo get_env('poster'); ?>">

    <!-- twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo get_env('title'); ?>">
    <meta name="twitter:description" content="<?php echo get_env('description'); ?>">
    <meta name="twitter:image" content="<?php echo get_env('poster'); ?>">

    <link rel="manifest" href="manifest.webmanifest">
    <link rel="mask-icon" href="assets/img/maskable_icon.png" color="#ffffff">

    <link rel="shortcut icon" href="favicon.ico" type="image/ico">
    <link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/img/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/img/apple-touch-icon-152x152-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/img/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/img/apple-touch-icon-120x120-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/img/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/apple-touch-icon-precomposed.png">

    <title><?php echo get_env('title') . ' - ' . get_env('site_name'); ?></title>

    <link rel="preconnect" href="//t.dtscdn.com">
    <link rel="preconnect" href="//e.dtscout.com">
    <link rel="preconnect" href="//s4.histats.com">
    <link rel="preconnect" href="//s10.histats.com">
    <link rel="preconnect" href="//tags.bluekai.com">
    <link rel="preconnect" href="//www.gstatic.com">
    <link rel="preconnect" href="//fonts.gstatic.com">
    <link rel="preconnect" href="//www.googleapis.com">
    <link rel="preconnect" href="//www.googletagmanager.com">
    <link rel="preconnect" href="//www.google.com">
    <link rel="preconnect" href="//www.google-analytics.com">
    <link rel="preconnect" href="//static.cloudflareinsights.com">
    <link rel="preconnect" href="//googleusercontent.com">
    <link rel="preconnect" href="//lh3.googleusercontent.com">
    <link rel="preconnect" href="//drive-thirdparty.googleusercontent.com">
    <link rel="preconnect" href="//static.addtoany.com">

    <link rel="preload" href="assets/vendor/bootstrap/css/bootstrap.min.css" as="style">
    <link rel="preload" href="assets/vendor/fontawesome6/css/all.min.css" as="style">
    <link rel="preload" href="assets/css/sweetalert.css" as="style">
    <link rel="preload" href="assets/css/style.css" as="style">

    <link rel="preload" href="assets/vendor/jquery.min.js" as="script">
    <link rel="preload" href="assets/vendor/FormData.js" as="script">
    <link rel="preload" href="assets/vendor/js.cookie.min.js" as="script">
    <link rel="preload" href="assets/vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
    <link rel="preload" href="assets/vendor/bs-custom-file-input/bs-custom-file-input.min.js" as="script">
    <link rel="preload" href="assets/vendor/sweetalert.min.js" as="script">

    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="assets/vendor/fontawesome6/css/all.min.css" media="all">
    <link rel="stylesheet" href="assets/css/sweetalert.css" media="all">

    <?php
    $cssLinks = $plugins->getFrontendCSS(true);
    if ($cssLinks) {
        session_write_close();
        echo $cssLinks;
    }
    ?>

    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        a,
        .page-link,
        .btn-outline-custom {
            color: <?php echo $customColor; ?>;
        }

        .btn-outline-custom {
            border-color: <?php echo $customColor; ?>;
        }

        a:hover,
        .page-link:hover {
            color: <?php echo $customColor2; ?>;
        }

        .border-custom {
            border-color: <?php echo $customColor; ?> !important;
        }

        .page-item.active .page-link,
        .dropdown-item.active,
        .dropdown-item:active,
        .bg-custom,
        .btn-custom,
        .nav-pills .nav-link.active,
        .nav-pills .show>.nav-link {
            color: #fff;
            border-color: <?php echo $customColor; ?>;
            background-image: -webkit-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
            background-image: -moz-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
            background-image: -o-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
            background-image: linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
            background-color: <?php echo $customColor; ?>;
        }

        .btn-outline-custom.active,
        .btn-outline-custom:active,
        .btn-outline-custom.focus,
        .btn-outline-custom:focus,
        .btn-outline-custom:not(:disabled):hover,
        .btn-custom.focus,
        .btn-custom:focus,
        .btn-custom:not(:disabled):hover {
            color: #fff !important;
            border-color: <?php echo $customColor2; ?>;
            background-image: -webkit-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
            background-image: -moz-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
            background-image: -o-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
            background-image: linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
            background-color: <?php echo $customColor2; ?>;
        }

        .page-link:focus,
        .btn-outline-custom.focus,
        .btn-outline-custom:focus,
        .btn-outline-custom:not(:disabled):hover,
        .btn-custom.focus,
        .btn-custom:focus {
            box-shadow: 0 0 0 .2rem rgba(<?php echo $rgbColor; ?>, .2);
        }

        .table-hover tbody tr:hover td {
            background-color: rgba(<?php echo $rgbColor; ?>, .07) !important;
        }
    </style>

    <script src="assets/vendor/jquery.min.js"></script>
    <script src="assets/vendor/FormData.js" defer></script>
    <script src="assets/vendor/js.cookie.min.js" defer></script>
    <script>
        var $ = jQuery.noConflict(),
            uid = <?php echo $userLogin ? $userLogin['id'] : 0; ?>,
            email = '<?php echo $userLogin ? $userLogin['email'] : ''; ?>',
            baseURL = '<?php echo BASE_URL; ?>',
            adminURL = '<?php echo ADMIN_URL; ?>/',
            languages = <?php echo json_encode(array_values(language_list())); ?>,
            showModalUpdate = false,
            oldDBVersion = <?php echo intval(get_option('updated')); ?>,
            newDBVersion = <?php echo DB_VERSION; ?>;
    </script>

    <?php
    echo $html->google_alaytics();
    echo $html->GTM_head();
    ?>
</head>

<body class="bg-light mb-5">
    <?php
    echo $html->GTM_body();
    ?>
    <a class="sr-only sr-only-focusable" href="#main">Skip to main content</a>
    <div class="container-xl bg-white shadow rounded-bottom">
        <header id="header">
            <nav class="navbar navbar-expand-lg navbar-dark container-xl fixed-top shadow bg-custom">
                <a class="navbar-brand" href=""><?php echo get_env('site_name'); ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse navbar-nav-scroll" id="navbarCollapse" style="max-height:calc(100vh - 56px)">
                    <ul class="navbar-nav ml-auto">
                        <?php
                        $anonymous = get_option('anonymous_generator');
                        echo $html->createMenu('Home', BASE_URL, '', 'fas fa-home mr-2');
                        if ($isAdmin || (!empty($anonymous) && validate_boolean($anonymous) && validate_boolean(get_option('enable_gsharer')))) {
                            session_write_close();
                            echo $html->createMenu('Bypass Limit', BASE_URL . 'sharer/', '', 'fab fa-google-drive mr-2');
                        }
                        if ($userLogin) {
                            session_write_close();
                            echo $html->createMenu('User Panel', ADMIN_URL . '/dashboard/', '', 'fas fa-user-circle mr-2', array(
                                $html->createSubMenu('Dashboard', ADMIN_URL . '/dashboard/', '', 'fas fa-tachometer-alt mr-2'),
                                $html->createSubMenu('My Videos', ADMIN_URL . '/videos/list/', '', 'fas fa-film mr-2'),
                                $html->createSubMenu('My Account', ADMIN_URL . '/profile/', '', 'fas fa-user mr-2'),
                                $html->createSubMenuDivider(),
                                $html->createSubMenu('Logout', ADMIN_URL . '/login/?logout=true', '', 'fas fa-sign-out-alt mr-2'),
                            ));
                        } else {
                            session_write_close();
                            echo $html->createMenu('Login', ADMIN_URL . '/login/', '', 'fas fa-sign-in-alt mr-2');
                            if (!file_exists(BASE_DIR . '.rent') && !filter_var(get_option('disable_registration'), FILTER_VALIDATE_BOOLEAN)) {
                                session_write_close();
                                echo $html->createMenu('Register', ADMIN_URL . '/register/', '', 'fas fa-user-plus mr-2');
                            }
                        }
                        $dev = parse_url(BASE_URL, PHP_URL_HOST);
                        if (strpos($dev, 'gdplayer.') !== false || strpos($dev, 'localhost') !== false) {
                            session_write_close();
                            echo $html->createMenu('Live TV', 'https://gdplayer.tv/', '', 'fas fa-tv mr-2');
                            echo $html->createMenu('Buy', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2', array(
                                $html->createSubMenu('Buy Source Code', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2'),
                                $html->createSubMenu('Buy Additional Hosts', BASE_URL . 'buy-additional-host/', '', 'fas fa-plus-circle mr-2')
                            ), 'btn btn-block btn-green', 'dropdown-menu-right');
                        }
                        ?>
                    </ul>
                </div>
            </nav>
        </header>
        <main id="main" class="pb-5" style="margin-top:56px">
