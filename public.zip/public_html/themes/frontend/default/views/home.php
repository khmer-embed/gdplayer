<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

$silencePage = '<div style="text-align:center">Silence is golden!</div>';
$currentUser = current_user();
$allowAnonymous = validate_boolean(get_option('anonymous_generator'));
if ($allowAnonymous || $currentUser) {
    if (is_load_balancer()) {
        $mainSite = get_option('main_site');
        if (validate_url($mainSite)) {
            header('location: ' . $mainSite);
            exit();
        } else {
            http_response_code(404);
            echo $silencePage;
            exit();
        }
    }
} else {
    http_response_code(404);
    echo $silencePage;
    exit();
}

$html = new \GDPlayer\HTML();

set_env('title', get_option('site_slogan'));
set_env('description', get_option('site_description'));
get_frontend_header();
?>
<div class="row">
    <div class="col py-5 bg-custom text-center">
        <h1 class="h3"><?php echo get_env('title'); ?></h1>
        <p><?php echo htmlspecialchars_decode(get_env('description')); ?></p>
    </div>
</div>
<div class="row my-3">
    <div class="col">
        <?php echo $html->createPlayerGenerator(); ?>
    </div>
</div>
<?php if (strpos(BASE_URL, 'gdplayer.to') !== false) : ?>
    <div class="row my-3">
        <div class="col">
            <?php
            echo $html->renderFrontendTemplate('sponsored.html.twig', [
                'title' => 'Ads',
                'list' => sponsored()
            ]);
            ?>
        </div>
    </div>
<?php endif; ?>
<?php
echo $html->createPlayerResult();
echo $html->hostLinkExample();
echo $html->disqus();

get_frontend_footer();
