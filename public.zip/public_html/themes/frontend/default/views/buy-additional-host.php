<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

set_env('title', 'Buy GDPlayer Google Drive Video Player');
set_env('description', 'Buy GDPlayer Google Drive Video Player Full Version only on the official site. Get lifetime update support.');
get_frontend_header();
?>
<div class="row pt-5">
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy All Additional Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$25</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/7eaba9cad4" target="_blank" class="btn btn-block btn-warning">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy Cloudvideo Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/ac08833104" target="_blank" class="btn btn-block btn-primary">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy Embedgram Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/9061f85786" target="_blank" class="btn btn-block btn-danger">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy Streamhub.to Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/8c3084ce00" target="_blank" class="btn btn-block btn-secondary">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy V LIVE Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/56954e6b4b" target="_blank" class="btn btn-block btn-success">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header text-center">
                <h2 class="card-title h5">Buy vTube.to Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body text-center">
                <a rel="noopener" href="https://ko-fi.com/s/2e4807a40e" target="_blank" class="btn btn-block btn-custom">Buy Now</a>
            </div>
        </div>
    </div>
</div>
<?php
get_frontend_footer();
