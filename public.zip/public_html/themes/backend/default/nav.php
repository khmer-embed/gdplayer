<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
?>
<header id="header" class="container-xl fixed-top bg-white shadow">
    <?php
    echo $html->licenseDialog();
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-custom row">
        <a class="navbar-brand" href="<?php echo ADMIN_URL; ?>/">Control Panel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse navbar-nav-scroll" id="navbarCollapse" style="max-height:calc(100vh - 50px)">
            <?php
            $iGear = 'fas fa-gear mr-2';
            $iPlusCircle = 'fas fa-plus-circle mr-2';
            $iAngleDoubleRight = 'fas fa-angle-double-right text-right mr-2';
            $generalMenuURL = ADMIN_URL . '/settings/general/';
            $closeUL = '</ul>';
            if ($userLogin) {
                echo '<ul class="navbar-nav">';
                echo $html->createMenu('Home', BASE_URL, 'd-lg-none ml-2', 'fas fa-home');
                echo $html->createMenu('Dashboard', ADMIN_URL . '/dashboard/', '', 'fas fa-tachometer-alt mr-2');
                echo $html->createMenu('Videos', ADMIN_URL . '/videos/list/', '', 'fas fa-film mr-2', array(
                    $html->createSubMenu('Add New Video', ADMIN_URL . '/videos/new/', '', $iPlusCircle),
                    $html->createSubMenuDivider(),
                    $html->createSubMenu('Video List', ADMIN_URL . '/videos/list/', '', 'fas fa-film mr-2'),
                    $html->createSubMenu('Subtitle Manager', ADMIN_URL . '/videos/subtitles/', '', 'fas fa-copy mr-2')
                ));
                if (intval($userLogin['role']) === 0) {
                    echo $html->createMenu('Google Drive', ADMIN_URL . '/gdrive/list/', '', 'fab fa-google-drive mr-2', array(
                        $html->createSubMenu('Add New Account', ADMIN_URL . '/gdrive/new/', '', $iPlusCircle),
                        $html->createSubMenuDivider(),
                        $html->createSubMenu('Account List', ADMIN_URL . '/gdrive/list/', '', 'fas fa-key text-right mr-2'),
                        $html->createSubMenu('File List', ADMIN_URL . '/gdrive/files/', '', 'fas fa-copy mr-2'),
                        $html->createSubMenu('Backup File List', ADMIN_URL . '/gdrive/backup-files/', '', 'fas fa-clone mr-2'),
                        $html->createSubMenu('Backup Queue List', ADMIN_URL . '/gdrive/backup-queue/', '', 'fas fa-calendar-check mr-2')
                    ));
                    echo $html->createMenu('Users', ADMIN_URL . '/users/list/', '', 'fas fa-users mr-2', array(
                        $html->createSubMenu('Add New User', ADMIN_URL . '/users/new/', '', $iPlusCircle),
                        $html->createSubMenuDivider(),
                        $html->createSubMenu('User List', ADMIN_URL . '/users/list/', '', 'fas fa-users mr-2'),
                        $html->createSubMenu('Session List', ADMIN_URL . '/users/sessions/', '', 'fas fa-history mr-2')
                    ));
                    $appSubmenu = array(
                        $html->createSubMenuHeader('Settings', '', $iGear),
                        $html->createSubMenu('Website', ADMIN_URL . '/settings/web/', '', $iAngleDoubleRight),
                        $html->createSubMenu('General', $generalMenuURL, '', $iAngleDoubleRight),
                        $html->createSubMenu('Public', ADMIN_URL . '/settings/public/', '', $iAngleDoubleRight),
                        $html->createSubMenu('Video Player', ADMIN_URL . '/settings/video/', '', $iAngleDoubleRight),
                        $html->createSubMenu('Advertisement', ADMIN_URL . '/settings/ads/', '', $iAngleDoubleRight),
                        $html->createSubMenu('Shortener Link', ADMIN_URL . '/settings/shortlink/', '', $iAngleDoubleRight),
                        $html->createSubMenu('SMTP', ADMIN_URL . '/settings/smtp/', '', $iAngleDoubleRight),
                        $html->createSubMenu('Miscellaneous', ADMIN_URL . '/settings/misc/', '', $iAngleDoubleRight)
                    );
                    $appSubmenu = array_merge(array(
                        $html->createSubMenuHeader('Load Balancer', '', 'fas fa-server mr-2'),
                        $html->createSubMenu('Servers', ADMIN_URL . '/settings/load-balancers/list/', '', $iAngleDoubleRight),
                        $html->createSubMenuDivider()
                    ), $appSubmenu, array(
                        $html->createSubMenu('Reset Settings', ADMIN_URL . '/settings/reset/', '', $iAngleDoubleRight)
                    ));
                    echo $html->createMenu('App', $generalMenuURL, '', $iGear, $appSubmenu);
                    echo $html->createMenu('Plugins', ADMIN_URL . '/plugins/list/', '', 'fas fa-puzzle-piece mr-2');
                }
                echo $closeUL;
                echo '<ul class="navbar-nav ml-auto">';
                echo $html->createMenu($userLogin['name'], ADMIN_URL . '/profile/', '', 'fas fa-user-circle mr-2', array(
                    $html->createSubMenu('My Account', ADMIN_URL . '/profile/', '', 'fas fa-user mr-2'),
                    $html->createSubMenuDivider(),
                    $html->createSubMenu('Logout', ADMIN_URL . '/login/?logout=true', '', 'fas fa-sign-out-alt mr-2')
                ), 'nav-link', 'dropdown-menu-right');
                echo $closeUL;
            } else {
                echo '<ul class="navbar-nav ml-auto">';
                echo $html->createMenu('Home', BASE_URL, '', 'fas fa-home mr-2');
                echo $html->createMenu('Login', ADMIN_URL . '/login/', '', 'fas fa-sign-in-alt mr-2');
                if (!file_exists(BASE_DIR . '.rent') && !filter_var(get_option('disable_registration'), FILTER_VALIDATE_BOOLEAN)) {
                    echo $html->createMenu('Register', ADMIN_URL . '/register/', '', 'fas fa-user-plus mr-2');
                }
                echo $html->createMenu('Reset Password', ADMIN_URL . '/reset-password/', '', 'fas fa-sync-alt mr-2');

                $devHost = parse_url(BASE_URL, PHP_URL_HOST);
                if (strpos($devHost, 'gdplayer.') !== false || strpos($devHost, 'localhost') !== false) {
                    echo $html->createMenu('Live TV', 'https://gdplayer.tv/', '', 'fas fa-tv mr-2');
                    echo $html->createMenu('Buy', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2', array(
                        $html->createSubMenu('Buy Source Code', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2'),
                        $html->createSubMenu('Buy Additional Hosts', BASE_URL . 'buy-additional-host/', '', $iPlusCircle),
                        $html->createSubMenu('Rent Server', BASE_URL . 'rent/', '', 'fas fa-server mr-2')
                    ), 'btn btn-block btn-green', 'dropdown-menu-right');
                }
                echo $closeUL;
            }
            ?>
        </div>
    </nav>
</header>
