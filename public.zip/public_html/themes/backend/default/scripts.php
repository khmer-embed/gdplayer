<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
?>
<script src="assets/vendor/jquery-ui.min.js" defer></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
<script src="assets/vendor/pwacompat.min.js"></script>
<script src="assets/vendor/js.cookie.min.js" defer></script>
<script src="assets/vendor/sweetalert.min.js" defer></script>
<script src="assets/vendor/toastify-js/toastify.min.js" defer></script>
<script src="assets/vendor/bs-custom-file-input/bs-custom-file-input.min.js" defer></script>
<script src="assets/vendor/datatables/datatables.min.js" defer></script>
<script src="assets/vendor/select2/js/select2.min.js" defer></script>
<script src="assets/vendor/jquery-wheelcolorpicker/jquery.wheelcolorpicker.min.js" defer></script>
<script src="assets/vendor/apexcharts/apexcharts.min.js" defer></script>
<script src="assets/vendor/jquery.multi-select.js" defer></script>
<script src="assets/js/md5.js" defer></script>
<script src="assets/js/main.js"></script>
<?php
$script = $plugins->getBackendJS(true);
if ($script) {
    echo $script;
}
echo $html->recaptcha();
echo $html->histats();
echo htmlspecialchars_decode(get_option('chat_widget'), ENT_QUOTES);
?>
<script>
    if ("serviceWorker" in navigator) {
        navigator.serviceWorker
            .register('sw.js')
            .then(function(res) {
                console.log("service worker registered");
            })
            .catch(function(err) {
                console.log("service worker not registered", err);
            });
    }
</script>
