<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

$plugins = new \GDPlayer\Plugins();

$themeColor = get_option('pwa_themecolor');
$themeColor = !empty($themeColor) ? '#' . $themeColor : '#673ab7';
$rgbColor = hex2RGB(trim($themeColor, '#'), true, ',');
$rgbColor = $rgbColor ? $rgbColor : '103, 58, 183';

$customColor = get_option('custom_color');
$customColor = !empty($customColor) ? '#' . $customColor : '#673ab7';

$customColor2 = get_option('custom_color2');
$customColor2 = !empty($customColor2) ? '#' . $customColor2 : '#3f51b5';
?>
<link rel="preload" href="assets/vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="assets/vendor/fontawesome6/css/all.min.css" as="style">
<link rel="preload" href="assets/css/sweetalert.css" as="style">
<link rel="preload" href="assets/css/multi-select.dist.css" as="style">
<link rel="preload" href="assets/vendor/select2/css/select2.min.css" as="style">
<link rel="preload" href="assets/css/select2-bootstrap4.min.css" as="style">
<link rel="preload" href="assets/vendor/jquery-wheelcolorpicker/css/wheelcolorpicker.css" as="style">
<link rel="preload" href="assets/vendor/toastify-js/toastify.min.css" as="style">
<link rel="preload" href="assets/vendor/apexcharts/apexcharts.css" as="style">
<link rel="preload" href="assets/css/style.css" as="style">

<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/fontawesome6/css/all.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
<link rel="stylesheet" type="text/css" href="assets/css/multi-select.dist.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/datatables/datatables.min.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/select2/css/select2.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/select2-bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/jquery-wheelcolorpicker/css/wheelcolorpicker.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/toastify-js/toastify.min.css">
<link rel="stylesheet" type="text/css" href="assets/vendor/apexcharts/apexcharts.css">

<?php
$cssLinks = $plugins->getBackendCSS(true);
if ($cssLinks) {
    echo $cssLinks;
}
?>

<link rel="stylesheet" type="text/css" href="assets/css/style.css">

<style>
    a,
    .page-link,
    .btn-outline-custom {
        color: <?php echo $customColor; ?>;
    }

    .btn-outline-custom {
        border-color: <?php echo $customColor; ?>;
    }

    a:hover,
    .page-link:hover {
        color: <?php echo $customColor2; ?>;
    }

    .border-custom {
        border-color: <?php echo $customColor; ?> !important;
    }

    .select2-container--bootstrap4 .select2-results__option--highlighted,
    .select2-container--bootstrap4 .select2-results__option--highlighted.select2-results__option[aria-selected=true],
    .page-item.active .page-link,
    .dropdown-item.active,
    .dropdown-item:active,
    .bg-custom,
    .btn-custom,
    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #fff;
        border-color: <?php echo $customColor; ?>;
        background-color: <?php echo $customColor; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>)
    }

    .btn-outline-custom.active,
    .btn-outline-custom:active,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus,
    .btn-custom:not(:disabled):hover {
        color: #fff !important;
        border-color: <?php echo $customColor2; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-color: <?php echo $customColor2; ?>;
    }

    .page-link:focus,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus {
        box-shadow: 0 0 0 .2rem rgba(<?php echo $rgbColor; ?>, .2) !important
    }

    .table-hover tbody tr:hover td {
        background-color: rgba(<?php echo $rgbColor; ?>, .07) !important;
    }

    #subsWrapper .input-group-prepend {
        max-width: 150px;
    }
</style>
