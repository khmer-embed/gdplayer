<?php
session_write_close();
include 'includes/includes.php';
include 'includes/views/api.php';
