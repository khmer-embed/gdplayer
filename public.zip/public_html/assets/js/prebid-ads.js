var canRunAds = true;
var n = new XMLHttpRequest();
n.onreadystatechange = function () {
    canRunAds = n.status !== 0;
};
n.open("GET", "https://feeloshu.com/tag.min.js", !0);
n.send();
