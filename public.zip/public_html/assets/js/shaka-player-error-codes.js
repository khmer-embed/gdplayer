var shakaErrorCodes = [
    {
        code: 1000,
        name: "UNSUPPORTED_SCHEME",
        description: "A network request was made using an unsupported URI scheme. error.data[0] is the URI.",
    },
    {
        code: 1001,
        name: "BAD_HTTP_STATUS",
        description: "An HTTP network request returned an HTTP status that indicated a failure. error.data[0] is the URI. error.data[1] is the status code. error.data[2] is the response text, or null if the response could not  be interpretted as text. error.data[3] is the map of response headers. error.data[4] is the NetworkingEngine.RequestType of the request,  if one was provided.",
    },
    {
        code: 1002,
        name: "HTTP_ERROR",
        description: "An HTTP network request failed with an error, but not from the server. error.data[0] is the URI. error.data[1] is the original error. error.data[2] is the NetworkingEngine.RequestType of the request.",
    },
    {
        code: 1003,
        name: "TIMEOUT",
        description: "A network request timed out. error.data[0] is the URI. error.data[1] is the NetworkingEngine.RequestType of the request,  if one was provided.",
    },
    {
        code: 1004,
        name: "MALFORMED_DATA_URI",
        description: "A network request was made with a malformed data URI. error.data[0] is the URI.",
    },
    {
        code: 1006,
        name: "REQUEST_FILTER_ERROR",
        description: "A request filter threw an error. error.data[0] is the original error.",
    },
    {
        code: 1007,
        name: "RESPONSE_FILTER_ERROR",
        description: "A response filter threw an error. error.data[0] is the original error.",
    },
    {
        code: 1008,
        name: "MALFORMED_TEST_URI",
        description: "A testing network request was made with a malformed URI.This error is only used by unit and integration tests.",
    },
    {
        code: 1009,
        name: "UNEXPECTED_TEST_REQUEST",
        description: "An unexpected network request was made to the FakeNetworkingEngine.This error is only used by unit and integration tests.",
    },
    {
        code: 1010,
        name: "ATTEMPTS_EXHAUSTED",
        description: "The number of retry attempts have run out.This is an internal error and shouldn't be propagated.",
    },
    {
        code: 2000,
        name: "INVALID_TEXT_HEADER",
        description: "The text parser failed to parse a text stream due to an invalid header.",
    },
    {
        code: 2001,
        name: "INVALID_TEXT_CUE",
        description: "The text parser failed to parse a text stream due to an invalid cue. error.data[0] is extra context, if available.",
    },
    {
        code: 2003,
        name: "UNABLE_TO_DETECT_ENCODING",
        description: "Was unable to detect the encoding of the response text.  Suggest addingbyte-order-markings to the response data.",
    },
    {
        code: 2004,
        name: "BAD_ENCODING",
        description: "The response data contains invalid Unicode character encoding.",
    },
    {
        code: 2005,
        name: "INVALID_XML",
        description: "The XML parser failed to parse an xml stream, or the XML lacks mandatoryelements for TTML. error.data[0] is extra context, if available.",
    },
    {
        code: 2007,
        name: "INVALID_MP4_TTML",
        description: "MP4 segment does not contain TTML.",
    },
    {
        code: 2008,
        name: "INVALID_MP4_VTT",
        description: "MP4 segment does not contain VTT.",
    },
    {
        code: 2009,
        name: "UNABLE_TO_EXTRACT_CUE_START_TIME",
        description: "When examining media in advance, we were unable to extract the cue time.This should only be possible with HLS, where we do not have explicitsegment start times. error.data[0] is the underlying exception or Error object.",
    },
    {
        code: 2010,
        name: "INVALID_MP4_CEA",
        description: "MP4 segment for CEA data is invalid.",
    },
    {
        code: 2011,
        name: "TEXT_COULD_NOT_GUESS_MIME_TYPE",
        description: "Unable to guess mime type of the text. error.data[0] is the text file's extension.",
    },
    {
        code: 2012,
        name: "CANNOT_ADD_EXTERNAL_TEXT_TO_SRC_EQUALS",
        description: "External text tracks cannot be added in src= because native platformdoesn't support it.",
    },
    {
        code: 2013,
        name: "TEXT_ONLY_WEBVTT_SRC_EQUALS",
        description: "Only WebVTT is supported when using src=. error.data[0] is the text MIME type.",
    },
    {
        code: 2014,
        name: "MISSING_TEXT_PLUGIN",
        description: "The compilation does not contain a required text plugin for thisoperation. error.data[0] is the text MIME type.",
    },
    {
        code: 3000,
        name: "BUFFER_READ_OUT_OF_BOUNDS",
        description: "Some component tried to read past the end of a buffer.  The segment index,init segment, or PSSH may be malformed.",
    },
    {
        code: 3001,
        name: "JS_INTEGER_OVERFLOW",
        description: "Some component tried to parse an integer that was too large to fit in aJavaScript number without rounding error.  JavaScript can only nativelyrepresent integers up to 53 bits.",
    },
    {
        code: 3002,
        name: "EBML_OVERFLOW",
        description: "The EBML parser used to parse the WebM container encountered an integer,ID, or other field larger than the maximum supported by the parser.",
    },
    {
        code: 3003,
        name: "EBML_BAD_FLOATING_POINT_SIZE",
        description: "The EBML parser used to parse the WebM container encountered a floating-point field of a size not supported by the parser.",
    },
    {
        code: 3004,
        name: "MP4_SIDX_WRONG_BOX_TYPE",
        description: "The MP4 SIDX parser found the wrong box type.Either the segment index range is incorrect or the data is corrupt.",
    },
    {
        code: 3005,
        name: "MP4_SIDX_INVALID_TIMESCALE",
        description: "The MP4 SIDX parser encountered an invalid timescale.The segment index data may be corrupt.",
    },
    {
        code: 3006,
        name: "MP4_SIDX_TYPE_NOT_SUPPORTED",
        description: "The MP4 SIDX parser encountered a type of SIDX that is not supported.",
    },
    {
        code: 3007,
        name: "WEBM_CUES_ELEMENT_MISSING",
        description: "The WebM Cues parser was unable to locate the Cues element.The segment index data may be corrupt.",
    },
    {
        code: 3008,
        name: "WEBM_EBML_HEADER_ELEMENT_MISSING",
        description: "The WebM header parser was unable to locate the Ebml element.The init segment data may be corrupt.",
    },
    {
        code: 3009,
        name: "WEBM_SEGMENT_ELEMENT_MISSING",
        description: "The WebM header parser was unable to locate the Segment element.The init segment data may be corrupt.",
    },
    {
        code: 3010,
        name: "WEBM_INFO_ELEMENT_MISSING",
        description: "The WebM header parser was unable to locate the Info element.The init segment data may be corrupt.",
    },
    {
        code: 3011,
        name: "WEBM_DURATION_ELEMENT_MISSING",
        description: "The WebM header parser was unable to locate the Duration element.The init segment data may be corrupt or may have been incorrectly encoded.Shaka requires a duration in WebM DASH content.",
    },
    {
        code: 3012,
        name: "WEBM_CUE_TRACK_POSITIONS_ELEMENT_MISSING",
        description: "The WebM Cues parser was unable to locate the Cue Track Positions element.The segment index data may be corrupt.",
    },
    {
        code: 3013,
        name: "WEBM_CUE_TIME_ELEMENT_MISSING",
        description: "The WebM Cues parser was unable to locate the Cue Time element.The segment index data may be corrupt.",
    },
    {
        code: 3014,
        name: "MEDIA_SOURCE_OPERATION_FAILED",
        description: "A MediaSource operation failed. error.data[0] is a MediaError code from the video element.",
    },
    {
        code: 3015,
        name: "MEDIA_SOURCE_OPERATION_THREW",
        description: "A MediaSource operation threw an exception. error.data[0] is the exception that was thrown.",
    },
    {
        code: 3016,
        name: "VIDEO_ERROR",
        description: "The video element reported an error. error.data[0] is a MediaError code from the video element. On Edge, error.data[1] is a Microsoft extended error code in hex. On Chrome, error.data[2] is a string with details on the error. See top of file for links to browser error codes.",
    },
    {
        code: 3017,
        name: "QUOTA_EXCEEDED_ERROR",
        description: "A MediaSource operation threw QuotaExceededError and recovery failed. Thecontent cannot be played correctly because the segments are too large forthe browser/platform. This may occur when attempting to play very highquality, very high bitrate content on low-end devices. error.data[0] is the type of content which caused the error.",
    },
    {
        code: 3018,
        name: "TRANSMUXING_FAILED",
        description: "Mux.js did not invoke the callback signifying successful transmuxing.",
    },
    {
        code: 3019,
        name: "CONTENT_TRANSFORMATION_FAILED",
        description: "Content transformations required by the platform could not be performed forsome reason (unsupported container, etc.)",
    },
    {
        code: 4000,
        name: "UNABLE_TO_GUESS_MANIFEST_TYPE",
        description: "The Player was unable to guess the manifest type based on file extensionor MIME type.  To fix, try one of the following: Rename the manifest so that the URI ends in a well-known extension. Configure the server to send a recognizable Content-Type header. Configure the server to accept a HEAD request for the manifest. error.data[0] is the manifest URI.",
    },
    {
        code: 4001,
        name: "DASH_INVALID_XML",
        description: "The DASH Manifest contained invalid XML markup. error.data[0] is the URI associated with the XML.",
    },
    {
        code: 4002,
        name: "DASH_NO_SEGMENT_INFO",
        description: "The DASH Manifest contained a Representation with insufficient segmentinformation.",
    },
    {
        code: 4003,
        name: "DASH_EMPTY_ADAPTATION_SET",
        description: "The DASH Manifest contained an AdaptationSet with no Representations.",
    },
    {
        code: 4004,
        name: "DASH_EMPTY_PERIOD",
        description: "The DASH Manifest contained an Period with no AdaptationSets.",
    },
    {
        code: 4005,
        name: "DASH_WEBM_MISSING_INIT",
        description: "The DASH Manifest does not specify an init segment with a WebM container.",
    },
    {
        code: 4006,
        name: "DASH_UNSUPPORTED_CONTAINER",
        description: "The DASH Manifest contained an unsupported container format.",
    },
    {
        code: 4007,
        name: "DASH_PSSH_BAD_ENCODING",
        description: "The embedded PSSH data has invalid encoding.",
    },
    {
        code: 4008,
        name: "DASH_NO_COMMON_KEY_SYSTEM",
        description: "There is an AdaptationSet whose Representations do not have any commonkey-systems.",
    },
    {
        code: 4009,
        name: "DASH_MULTIPLE_KEY_IDS_NOT_SUPPORTED",
        description: "Having multiple key IDs per Representation is not supported.",
    },
    {
        code: 4010,
        name: "DASH_CONFLICTING_KEY_IDS",
        description: "The DASH Manifest specifies conflicting key IDs.",
    },
    {
        code: 4012,
        name: "RESTRICTIONS_CANNOT_BE_MET",
        description: "There exist some streams that could be decoded, but restrictions imposedby the application or the key system prevent us from playing.  This mayhappen under the following conditions: The application has given restrictions to the Player that restrict      at least one content type completely (e.g. no playable audio). The manifest specifies different keys than were given to us from the      license server. The key system has imposed output restrictions that cannot be met      (such as HDCP) and there are no unrestricted alternatives. error.data[0] is a shaka.extern.RestrictionInfo objectdescribing the kinds of restrictions that caused this error.",
    },
    {
        code: 4015,
        name: "HLS_PLAYLIST_HEADER_MISSING",
        description: "HLS playlist doesn't start with a mandory #EXTM3U tag.",
    },
    {
        code: 4016,
        name: "INVALID_HLS_TAG",
        description: "HLS tag has an invalid name that doesn't start with '#EXT' error.data[0] is the invalid tag.",
    },
    {
        code: 4017,
        name: "HLS_INVALID_PLAYLIST_HIERARCHY",
        description: "HLS playlist has both Master and Media/Segment tags.",
    },
    {
        code: 4018,
        name: "DASH_DUPLICATE_REPRESENTATION_ID",
        description: "A Representation has an id that is the same as another Representation inthe same Period.  This makes manifest updates impossible since we cannotmap the updated Representation to the old one.",
    },
    {
        code: 4020,
        name: "HLS_MULTIPLE_MEDIA_INIT_SECTIONS_FOUND",
        description: "HLS manifest has several #EXT-X-MAP tags. We can onlysupport one at the moment.",
    },
    {
        code: 4022,
        name: "HLS_MASTER_PLAYLIST_NOT_PROVIDED",
        description: "No Master Playlist has been provided. Master playlist providesvital information about the streams (like codecs) that isrequired for MediaSource. We don't support directly providinga Media Playlist.",
    },
    {
        code: 4023,
        name: "HLS_REQUIRED_ATTRIBUTE_MISSING",
        description: "One of the required attributes was not provided, so theHLS manifest is invalid. error.data[0] is the missing attribute's name.",
    },
    {
        code: 4024,
        name: "HLS_REQUIRED_TAG_MISSING",
        description: "One of the required tags was not provided, so theHLS manifest is invalid. error.data[0] is the missing tag's name.",
    },
    {
        code: 4025,
        name: "HLS_COULD_NOT_GUESS_CODECS",
        description: "The HLS parser was unable to guess codecs of a stream. error.data[0] is the list of all codecs for the variant.",
    },
    {
        code: 4026,
        name: "HLS_KEYFORMATS_NOT_SUPPORTED",
        description: "The HLS parser has encountered encrypted content with unsupportedKEYFORMAT attributes.",
    },
    {
        code: 4027,
        name: "DASH_UNSUPPORTED_XLINK_ACTUATE",
        description: 'The manifest parser only supports xlink links with xlink:actuate="onLoad".',
    },
    {
        code: 4028,
        name: "DASH_XLINK_DEPTH_LIMIT",
        description: "The manifest parser has hit its depth limit on xlink link chains.",
    },
    {
        code: 4030,
        name: "HLS_COULD_NOT_PARSE_SEGMENT_START_TIME",
        description: "The HLS parser was unable to parse segment start time from the media. error.data[0] is the failed media playlist URI. error.data[1] is the failed media segment URI (if any).",
    },
    {
        code: 4032,
        name: "CONTENT_UNSUPPORTED_BY_BROWSER",
        description: "The content container or codecs are not supported by this browser. Forexample, this could happen if the content is WebM, but your browser doesnot support the WebM container, or if the content uses HEVC, but yourbrowser does not support the HEVC codec.  This can also occur formulticodec or multicontainer manifests if none of the codecs or containersare supported by the browser.To see what your browser supports, you can check the JSON data dumped byhttp://support.shaka-player-demo.appspot.com/",
    },
    {
        code: 4033,
        name: "CANNOT_ADD_EXTERNAL_TEXT_TO_LIVE_STREAM",
        description: "External text tracks cannot be added to live streams.",
    },
    {
        code: 4034,
        name: "HLS_AES_128_ENCRYPTION_NOT_SUPPORTED",
        description: "We do not support AES-128 encryption with HLS yet.",
    },
    {
        code: 4035,
        name: "HLS_INTERNAL_SKIP_STREAM",
        description: "An internal error code that should never be seen by applications, thrownto force the HLS parser to skip an unsupported stream.",
    },
    {
        code: 4036,
        name: "NO_VARIANTS",
        description: "The Manifest contained no Variants.",
    },
    {
        code: 4037,
        name: "PERIOD_FLATTENING_FAILED",
        description: "We failed to find matching streams across DASH Periods, and theperiod-flattening aglorithm introduced in v3.0 has failed.",
    },
    {
        code: 4038,
        name: "INCONSISTENT_DRM_ACROSS_PERIODS",
        description: "We failed to find matching streams across DASH Periods due to inconsistentDRM systems across periods.",
    },
    {
        code: 4039,
        name: "HLS_VARIABLE_NOT_FOUND",
        description: "The HLS manifest refers to an undeclared variables. error.data[0] is the variable undeclared.",
    },
    {
        code: 5006,
        name: "STREAMING_ENGINE_STARTUP_INVALID_STATE",
        description: "This would only happen if StreamingEngine were not started correctly, andshould not be seen in production.",
    },
    {
        code: 6000,
        name: "NO_RECOGNIZED_KEY_SYSTEMS",
        description: "The manifest indicated protected content, but the manifest parser wasunable to determine what key systems should be used.",
    },
    {
        code: 6001,
        name: "REQUESTED_KEY_SYSTEM_CONFIG_UNAVAILABLE",
        description: "None of the requested key system configurations are available.  This mayhappen under the following conditions: The key system is not supported. The key system does not support the features requested (e.g.       persistent state). A user prompt was shown and the user denied access. The key system is not available from unsecure contexts. (i.e.            requires HTTPS) See https://bit.ly/2K9X1nY",
    },
    {
        code: 6002,
        name: "FAILED_TO_CREATE_CDM",
        description: "The browser found one of the requested key systems, but it failed tocreate an instance of the CDM for some unknown reason. error.data[0] is an error message string from the browser.",
    },
    {
        code: 6003,
        name: "FAILED_TO_ATTACH_TO_VIDEO",
        description: "The browser found one of the requested key systems and created an instanceof the CDM, but it failed to attach the CDM to the video for some unknownreason. error.data[0] is an error message string from the browser.",
    },
    {
        code: 6004,
        name: "INVALID_SERVER_CERTIFICATE",
        description: "The CDM rejected the server certificate supplied by the application.The certificate may be malformed or in an unsupported format. error.data[0] is an error message string from the browser.",
    },
    {
        code: 6005,
        name: "FAILED_TO_CREATE_SESSION",
        description: "The CDM refused to create a session for some unknown reason. error.data[0] is an error message string from the browser.",
    },
    {
        code: 6006,
        name: "FAILED_TO_GENERATE_LICENSE_REQUEST",
        description: "The CDM was unable to generate a license request for the init data it wasgiven.  The init data may be malformed or in an unsupported format. error.data[0] is an error message string from the browser. error.data[1] is the error object from the browser. error.data[2] is a string with the extended error code, if available. See top of file for links to browser error codes.",
    },
    {
        code: 6007,
        name: "LICENSE_REQUEST_FAILED",
        description: "The license request failed.  This could be a timeout, a network failure, ora rejection by the server. error.data[0] is a shaka.util.Error from the networking engine.",
    },
    {
        code: 6008,
        name: "LICENSE_RESPONSE_REJECTED",
        description: "The license response was rejected by the CDM.  The server's response may beinvalid or malformed for this CDM. error.data[0] is an error message string from the browser. See top of file for links to browser error codes.",
    },
    {
        code: 6010,
        name: "ENCRYPTED_CONTENT_WITHOUT_DRM_INFO",
        description: "The manifest does not specify any DRM info, but the content is encrypted.Either the manifest or the manifest parser are broken.",
    },
    {
        code: 6012,
        name: "NO_LICENSE_SERVER_GIVEN",
        description: "No license server was given for the key system signaled by the manifest.A license server URI is required for every key system. error.data[0] is the key system identifier.",
    },
    {
        code: 6013,
        name: "OFFLINE_SESSION_REMOVED",
        description: "A required offline session was removed.  The content is not playable.",
    },
    {
        code: 6014,
        name: "EXPIRED",
        description: "The license has expired.  This is triggered when all keys in the keystatus map have a status of 'expired'.",
    },
    {
        code: 6015,
        name: "SERVER_CERTIFICATE_REQUIRED",
        description: "A server certificate wasn't given when it is required.  FairPlay requiressetting an explicit server certificate in the configuration.",
    },
    {
        code: 6016,
        name: "INIT_DATA_TRANSFORM_ERROR",
        description: "An error was thrown while executing the init data transformation. error.data[0] is the original error.",
    },
    {
        code: 6017,
        name: "SERVER_CERTIFICATE_REQUEST_FAILED",
        description: "The server certificate request failed. error.data[0] is a shaka.util.Error from the networking engine.",
    },
    {
        code: 7000,
        name: "LOAD_INTERRUPTED",
        description: "The call to Player.load() was interrupted by a call to Player.unload()or another call to Player.load().",
    },
    {
        code: 7001,
        name: "OPERATION_ABORTED",
        description: "An internal error which indicates that an operation was aborted.  Thisshould not be seen by applications.",
    },
    {
        code: 7002,
        name: "NO_VIDEO_ELEMENT",
        description: "The call to Player.load() failed because the Player does not have a videoelement.  The video element must either be provided to the constructor orto Player.attach() before Player.load() is called.",
    },
    {
        code: 7003,
        name: "OBJECT_DESTROYED",
        description: "The operation failed because the object has been destroyed.",
    },
    {
        code: 7004,
        name: "CONTENT_NOT_LOADED",
        description: "The content has not been loaded in the Player.",
    },
    {
        code: 8000,
        name: "CAST_API_UNAVAILABLE",
        description: "The Cast API is unavailable.  This may be because of one of the following: 1. The browser may not have Cast support 2. The browser may be missing a necessary Cast extension 3. The Cast sender library may not be loaded in your app",
    },
    {
        code: 8001,
        name: "NO_CAST_RECEIVERS",
        description: "No cast receivers are available at this time.",
    },
    {
        code: 8002,
        name: "ALREADY_CASTING",
        description: "The library is already casting.",
    },
    {
        code: 8003,
        name: "UNEXPECTED_CAST_ERROR",
        description: "A Cast SDK error that we did not explicitly plan for has occurred.Check data[0] and refer to the Cast SDK documentation for details. error.data[0] is an error object from the Cast SDK.",
    },
    {
        code: 8004,
        name: "CAST_CANCELED_BY_USER",
        description: "The cast operation was canceled by the user. error.data[0] is an error object from the Cast SDK.",
    },
    {
        code: 8005,
        name: "CAST_CONNECTION_TIMED_OUT",
        description: "The cast connection timed out. error.data[0] is an error object from the Cast SDK.",
    },
    {
        code: 8006,
        name: "CAST_RECEIVER_APP_UNAVAILABLE",
        description: "The requested receiver app ID does not exist or is unavailable.Check the requested app ID for typos. error.data[0] is an error object from the Cast SDK.",
    },
    {
        code: 9000,
        name: "STORAGE_NOT_SUPPORTED",
        description: "Offline storage is not supported on this browser; it is required foroffline support.",
    },
    {
        code: 9001,
        name: "INDEXED_DB_ERROR",
        description: "An unknown error occurred in the IndexedDB. On Firefox, one common source for UnknownError calls is revertingFirefox to an old version. This makes the IndexedDB storage inaccessiblefor older versions. The only way to fix this is to delete the storagedata in your profile. See https://mzl.la/2yCGWCm error.data[0] is the error object.",
    },
    {
        code: 9002,
        name: "DEPRECATED_OPERATION_ABORTED",
        description: "The storage operation was aborted.  Deprecated in favor of more generalOPERATION_ABORTED.",
    },
    {
        code: 9003,
        name: "REQUESTED_ITEM_NOT_FOUND",
        description: "The specified item was not found in the IndexedDB. error.data[0] is the offline URI.",
    },
    {
        code: 9004,
        name: "MALFORMED_OFFLINE_URI",
        description: "A network request was made with a malformed offline URI. error.data[0] is the URI.",
    },
    {
        code: 9005,
        name: "CANNOT_STORE_LIVE_OFFLINE",
        description: "The specified content is live or in-progress.Live and in-progress streams cannot be stored offline. error.data[0] is the URI.",
    },
    {
        code: 9007,
        name: "NO_INIT_DATA_FOR_OFFLINE",
        description: "There was no init data available for offline storage.  This happens whenthere is no init data in the manifest nor could we find any in thesegments.  We currently only support searching MP4 init segments for initdata.",
    },
    {
        code: 9008,
        name: "LOCAL_PLAYER_INSTANCE_REQUIRED",
        description: "shaka.offline.Storage was constructed with a Player proxy instead of alocal player instance.  To fix this, use Player directly with Storageinstead of the results of CastProxy.prototype.getPlayer().",
    },
    {
        code: 9011,
        name: "NEW_KEY_OPERATION_NOT_SUPPORTED",
        description: "The storage cell does not allow new operations that require new keys.",
    },
    {
        code: 9012,
        name: "KEY_NOT_FOUND",
        description: "A key was not found in a storage cell.",
    },
    {
        code: 9013,
        name: "MISSING_STORAGE_CELL",
        description: "A storage cell was not found.",
    },
    {
        code: 9014,
        name: "STORAGE_LIMIT_REACHED",
        description: "The storage limit defined in downloadSizeCallback has beenreached.",
    },
    {
        code: 9015,
        name: "DOWNLOAD_SIZE_CALLBACK_ERROR",
        description: "downloadSizeCallback has produced an unexpected error.",
    },
    {
        code: 10000,
        name: "CS_IMA_SDK_MISSING",
        description: "CS IMA SDK, required for ad insertion, has not been included on the page.",
    },
    {
        code: 10001,
        name: "CS_AD_MANAGER_NOT_INITIALIZED",
        description: "Client Side Ad Manager needs to be initialized to enable Client SideAd Insertion. Call adManager.initClientSide() to do it.",
    },
    {
        code: 10002,
        name: "SS_IMA_SDK_MISSING",
        description: "SS IMA SDK, required for ad insertion, has not been included on the page.",
    },
    {
        code: 10003,
        name: "SS_AD_MANAGER_NOT_INITIALIZED",
        description: "Server Side Ad Manager needs to be initialized to enable Server SideAd Insertion. Call adManager.initServerSide() to do it.",
    },
    {
        code: 10004,
        name: "CURRENT_DAI_REQUEST_NOT_FINISHED",
        description: "A new DAI steam was requested before the previous request had beenresolved. Only one stream request at a time is supported. Please waitfor the previous request to complete before initiating a new one.",
    },
];
