var xStorage = {
    key: function (index) {
        return null;
    },
    getItem: function (key) {
        return null;
    },
    setItem: function (key, val) {
        return undefined;
    },
    removeItem: function (key) {
        return undefined;
    },
    clear: function () {
        return undefined;
    },
};
try {
    if (typeof window.localStorage !== "undefined") {
        xStorage = window.localStorage;
    } else if (typeof window.sessionStorage !== "undefined") {
        xStorage = window.sessionStorage;
    }
} catch (e) {
    gtagReport("load", e, "localStorage", false);
}
var validasi = typeof playerConfig !== "undefined" && "iv" in playerConfig,
    pConf = {};
if (validasi) {
    pConf = JSON.parse(_decx(JSON.stringify(playerConfig)));
} else {
    showMessage('Connection timed out! <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
    gtagReport("video_error", "Connection timed out", "plyr", false);
}
var $resume = $("#resume"),
    $myConfirm = $resume.find(".myConfirm > p:first-child"),
    $timez = $("#timez"),
    isLive = false,
    latestPlayKey = "latestplay." + pConf.localKey,
    latestPlayTime = xStorage.getItem(latestPlayKey),
    retryKey = "retry." + pConf.localKey,
    retryNumber = xStorage.getItem(retryKey),
    statLogInterval = false,
    statCounted = false,
    haveAds = typeof pConf.vastAds.schedule !== "undefined" && pConf.vastAds.schedule.length > 0,
    p2pEnabled = pConf.enableP2P && pConf.torrentList.length > 0 && typeof p2pml !== "undefined" && p2pml.core.HybridLoader.isSupported(),
    p2pConfig = {
        segments: {
            swarmId: pConf.localKey,
        },
        loader: {
            trackerAnnounce: pConf.torrentList,
            httpUseRanges: true,
            httpDownloadProbabilitySkipIfNoPeers: true,
        },
    },
    title = $("meta[name='og:title']").attr("content"),
    poster = $("meta[name='og:image']").attr("content"),
    jwp = {
        container: "videoContainer",
        player: null,
        config: {
            title: title,
            image: poster,
            rewind: false,
            abouttext: "GDPlayer.to",
            aboutlink: "https://gdplayer.to",
            controls: true,
            hlshtml: true,
            primary: "html5",
            autoplay: pConf.autoplay,
            mute: pConf.mute,
            preload: pConf.preload,
            repeat: pConf.repeat,
            cast: {},
            androidhls: true,
            stretching: pConf.stretching,
            displaytitle: pConf.displaytitle,
            displaydescription: false,
            playbackRateControls: pConf.displayRateControls,
            captions: {
                color: pConf.captionsColor,
                backgroundOpacity: 0,
            },
            sources: [],
            tracks: [],
            aspectratio: "16:9",
            floating: false,
            advertising: pConf.vastAds,
            logo: {
                file: pConf.logoImage,
                link: pConf.logoLink,
                hide: pConf.logoHide,
                position: pConf.logoPosition,
            },
        },
        resumePlayback: function () {
            $resume.hide();
            jwp.player.seek(xStorage.getItem(latestPlayKey));
        },
        destroy: function () {
            if (jwp.player) {
                jwp.player.remove();
                jwp.player = undefined;
            }
        },
        adblocker: function (blocked) {
            setTimeout(function () {
                if (pConf.blockADB && (blocked || !canRunAds)) {
                    jwp.destroy();
                    adblockerMessage();
                } else {
                    loadSources(
                        function (res) {
                            var $servers = $("#servers li"),
                                serverLen = $servers.length,
                                $next,
                                link = "";
                            if (res.status !== "fail") {
                                jwp.config.title = res.title;
                                jwp.config.image = res.poster;
                                jwp.config.tracks = res.tracks;
                                if ("filmstrip" in res && res.filmstrip !== "") {
                                    jwp.config.tracks.push({
                                        file: res.filmstrip,
                                        kind: "thumbnails",
                                    });
                                }
                                if (res.sources.length > 0) {
                                    jwp.config.sources = res.sources;
                                    jwp.loadPlayer(false);
                                } else {
                                    jwp.msg.notFound();
                                }
                            } else if (serverLen > 1) {
                                showLoading();
                                $servers.each(function (i, e) {
                                    if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                                        $next = $(this).next();
                                        if ($next.length > 0) {
                                            link = $next.find("a").attr("href");
                                            return false;
                                        }
                                    }
                                });
                                if (link !== "") {
                                    window.location.href = link;
                                } else {
                                    showMessage(res.message);
                                }
                            } else {
                                retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                                if (retryNumber < 3) {
                                    retry(retryNumber);
                                } else {
                                    jwp.msg.custom(res.message);
                                }
                            }
                        },
                        function (xhr, status) {
                            if (status === "timeout") {
                                jwp.msg.timeout();
                            } else {
                                failed();
                            }
                        }
                    );
                }
            }, 300);
        },
        loadPlayer: function (resume) {
            var p2pEngine;
            jwp.player = jwplayer(jwp.container);
            jwp.player.setup(jwp.config);
            if (p2pEnabled) {
                jwplayer_hls_provider.attach();
                p2pEngine = new p2pml.hlsjs.Engine(p2pConfig);
                p2pml.hlsjs.initJwPlayer(jwp.player, {
                    liveSyncDurationCount: 7,
                    loader: p2pEngine.createLoaderClass(),
                });
            }
            jwp.player.on("setupError error", jwp.errorHandler);
            jwp.player.once("ready", function () {
                var skinName = pConf.playerSkin,
                    iconRewind = jwp.icons.rewind,
                    iconForward = jwp.icons.forward,
                    iconDownload = jwp.icons.download,
                    changeTextDurationPosition = ["netflix", "hotstar"],
                    btnClassRole = 'class="jw-icon jw-icon-display jw-button-color jw-reset" role="button"';
                if (skinName in jwp.icons) {
                    if ("rewind" in jwp.icons[skinName]) {
                        iconRewind = jwp.icons[skinName].rewind;
                    }
                    if ("forward" in jwp.icons[skinName]) {
                        iconForward = jwp.icons[skinName].forward;
                    }
                    if ("download" in jwp.icons[skinName]) {
                        iconDownload = jwp.icons[skinName].download;
                    }
                }
                isLive = $(".jwplayer").hasClass("jw-flag-live");
                $(".jw-display-icon-rewind").html("<div " + btnClassRole + ' onclick="window.customRewind()">' + iconRewind + "</div>");
                $(".jw-display-icon-next")
                    .html("<div " + btnClassRole + ' onclick="window.customForward()">' + iconForward + "</div>")
                    .removeAttr("style");
                jwp.player.addButton(iconRewind, pConf.text_rewind, window.customRewind, "rewind");
                jwp.player.addButton(iconForward, pConf.text_forward, window.customForward, "forward");
                if (pConf.showDownloadButton && pConf.enableDownloadPage) {
                    jwp.player.addButton(
                        iconDownload,
                        pConf.text_download,
                        function () {
                            window.open(pConf.downloadLink, "_blank");
                            return true;
                        },
                        "download"
                    );
                }
                if (pConf.smallLogoFile !== "") {
                    jwp.player.addButton(
                        pConf.smallLogoFile,
                        "",
                        function () {
                            if (pConf.smallLogoURL !== "") {
                                window.open(pConf.smallLogoURL, "_blank");
                            }
                            return true;
                        },
                        "small_logo"
                    );
                }
                if (changeTextDurationPosition.indexOf(skinName) > -1) {
                    $(".jw-slider-time").prepend($(".jw-text-elapsed")).append($(".jw-text-duration"));
                }
                if (jwp.config.autoplay) {
                    xStorage.removeItem("autoplay");
                    jwp.player.play();
                    if (resume) {
                        jwp.player.seek(xStorage.getItem(latestPlayKey));
                    }
                }
                jwp.mediaSession.load();
                showPlayer();
                gtagReport("video_ready_to_play", "Ready To Play", "jwplayer", false);
            });
            jwp.player.once("beforePlay", function () {
                var $iconRewind = $(".jw-icon-rewind"),
                    $btnRewind = $('[button="rewind"]'),
                    $btnForward = $('[button="forward"]');
                if ($iconRewind.length) {
                    $iconRewind.after($btnRewind);
                    $btnRewind.after($btnForward);
                }
            });
            jwp.player.on("meta", function () {
                var timeFormat = "";
                if (!isLive && pConf.resumePlayback) {
                    latestPlayTime = xStorage.getItem(latestPlayKey);
                    if (latestPlayTime && $resume.length && jwp.player.getPosition() < Number(latestPlayTime)) {
                        timeFormat = prettySecond(latestPlayTime);
                        $timez.text(timeFormat);
                        $myConfirm.text($myConfirm.text().replace("hh:mm:ss", timeFormat));
                        $resume.show();
                    }
                }
            });
            jwp.player.on("time", function (event) {
                latestPlayTime = xStorage.getItem(latestPlayKey);
                if (event.position > latestPlayTime) {
                    xStorage.setItem(latestPlayKey, Math.round(event.position));
                    xStorage.removeItem(retryKey);
                }
                if (event.position >= pConf.statCounterRuntime && !statCounted) {
                    statCounter();
                }
            });
            jwp.player.once("complete playlistComplete", function () {
                if (statLogInterval) {
                    clearInterval(statLogInterval);
                    statLogInterval = false;
                }
                xStorage.removeItem(latestPlayKey);
                gtagReport("video_complete", "Playback Has Ended", "jwplayer", false);
            });
            jwp.player.once("play", function () {
                visitDirectAds();
            });
        },
        errorHandler: function (e) {
            var $servers = $("#servers li"),
                serverLen = $servers.length,
                $next,
                link = "",
                eDetail = "sourceError" in e && e.sourceError && "message" in e.sourceError ? e.sourceError.message : "";
            showLoading();
            if (serverLen > 1) {
                $servers.each(function (i, e) {
                    if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                        $next = $(this).next();
                        if ($next.length > 0) {
                            link = $next.find("a").attr("href");
                            return false;
                        }
                    }
                });
                if (link !== "") {
                    window.location.href = link;
                } else {
                    showPlayer();
                }
            } else {
                retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                if (retryNumber < 3) {
                    retry(retryNumber);
                } else if (e.code === 301161 && e.sourceError === null) {
                    gtagReport("video_error", "Redirected to https", "jwplayer", false);
                    location.href = location.href.replace("http:", "https:");
                } else {
                    gtagReport("video_error", e.message + " " + eDetail, "jwplayer", false);
                    showMessage(e.message + " " + eDetail + ' <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
                }
            }
        },
        loadSkin: function () {
            var skinName = pConf.playerSkin,
                skin = {};
            if (skinName !== "" && skinName !== "default") {
                skin = {
                    url: pConf.baseURL + "assets/css/skin/jwplayer/" + pConf.playerSkin + ".css",
                    name: pConf.playerSkin,
                    controlbar: {},
                    timeslider: {},
                    menus: {},
                };
                if (skinName === "netflix") {
                    skin.controlbar = {
                        icons: "#ffffff",
                        iconsActive: "#e50914",
                    };
                    skin.timeslider = {
                        progress: "#e50914",
                        rail: "#5b5b5b",
                    };
                    skin.menus = {
                        background: "#262626",
                        textActive: "#e50914",
                    };
                } else if (skinName === "hotstar") {
                    skin.controlbar = {
                        icons: "#ffffff",
                        iconsActive: "#1f80e0",
                    };
                    skin.timeslider = {
                        progress: "#1f80e0",
                        rail: "rgba(255,255,255,.2)",
                    };
                    skin.menus = {
                        background: "rgba(18,18,18,.95)",
                        textActive: "#1f80e0",
                    };
                }
            } else {
                skin = {
                    controlbar: {
                        iconsActive: pConf.playerColor,
                    },
                    timeslider: {
                        progress: pConf.playerColor,
                    },
                    menus: {
                        background: "#121212",
                        textActive: pConf.playerColor,
                    },
                };
            }
            return skin;
        },
        msg: {
            notFound: function () {
                showMessage("Sorry this video is unavailable.");
                gtagReport("video_error", "Sources not found", "jwplayer", false);
            },
            custom: function (msg) {
                showMessage(msg);
                gtagReport("video_error", msg, "jwplayer", false);
            },
            timeout: function () {
                showMessage('Connection timed out! <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
                gtagReport("video_error", "Connection timed out", "jwplayer", false);
            },
        },
        mediaSession: {
            updatePositionState: function (state) {
                if ("mediaSession" in navigator) {
                    if ("playbackState" in navigator.mediaSession) {
                        navigator.mediaSession.playbackState = state;
                    }
                    if (!isLive && "setPositionState" in navigator.mediaSession) {
                        navigator.mediaSession.setPositionState({
                            duration: jwp.player.getDuration(),
                            playbackRate: jwp.player.getPlaybackRate(),
                            position: jwp.player.getPosition(),
                        });
                    }
                }
            },
            load: function () {
                if ("mediaSession" in navigator) {
                    navigator.mediaSession.metadata = new MediaMetadata({
                        title: jwp.config.title,
                        artwork: [
                            {
                                src: jwp.config.image,
                            },
                        ],
                    });
                    navigator.mediaSession.setActionHandler("play", function () {
                        jwp.player.play();
                        jwp.mediaSession.updatePositionState("playing");
                    });
                    navigator.mediaSession.setActionHandler("pause", function () {
                        if (isLive) {
                            jwp.player.stop();
                        } else {
                            jwp.player.pause();
                        }
                        jwp.mediaSession.updatePositionState("paused");
                    });
                    navigator.mediaSession.setActionHandler("stop", function () {
                        jwp.player.stop();
                        jwp.mediaSession.updatePositionState("paused");
                    });
                    if (!isLive) {
                        navigator.mediaSession.setActionHandler("seekbackward", function () {
                            var seek = 0,
                                time = jwp.player.getPosition() - 10;
                            seek = time <= 0 ? 0 : time;
                            jwp.player.seek(seek);
                            jwp.mediaSession.updatePositionState("none");
                        });
                        navigator.mediaSession.setActionHandler("seekforward", function () {
                            var seek = 0,
                                time = jwp.player.getPosition() + 10;
                            seek = time <= 0 ? 0 : time;
                            jwp.player.seek(seek);
                            jwp.mediaSession.updatePositionState("none");
                        });
                    }
                }
            },
        },
        icons: {
            netflix: {
                rewind: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-rewind" viewBox="0 0 24 24" focusable="false"><g id="back-10"><path d="M12.4521632,5.01256342 L13.8137335,6.91876181 L12.1862665,8.08123819 L9.27109639,4 L12.1862665,-0.0812381937 L13.8137335,1.08123819 L12.4365066,3.0093558 C17.7568368,3.23786247 22,7.6234093 22,13 C22,18.5228475 17.5228475,23 12,23 C6.4771525,23 2,18.5228475 2,13 C2,11.0297737 2.57187523,9.14190637 3.62872363,7.52804389 L5.30188812,8.6237266 C4.4566948,9.91438076 4,11.4220159 4,13 C4,17.418278 7.581722,21 12,21 C16.418278,21 20,17.418278 20,13 C20,8.73346691 16.6600802,5.24701388 12.4521632,5.01256342 Z M8.47,17 L8.47,11.41 L6.81,11.92 L6.81,10.75 L9.79,9.91 L9.79,17 L8.47,17 Z M14.31,17.15 C13.7499972,17.15 13.2600021,17.0016682 12.84,16.705 C12.4199979,16.4083319 12.0950011,15.9883361 11.865,15.445 C11.6349988,14.901664 11.52,14.2600037 11.52,13.52 C11.52,12.786663 11.6349988,12.1466694 11.865,11.6 C12.0950011,11.0533306 12.4199979,10.6316682 12.84,10.335 C13.2600021,10.0383319 13.7499972,9.89 14.31,9.89 C14.8700028,9.89 15.3599979,10.0383319 15.78,10.335 C16.2000021,10.6316682 16.5249988,11.0533306 16.755,11.6 C16.9850012,12.1466694 17.1,12.786663 17.1,13.52 C17.1,14.2600037 16.9850012,14.901664 16.755,15.445 C16.5249988,15.9883361 16.2000021,16.4083319 15.78,16.705 C15.3599979,17.0016682 14.8700028,17.15 14.31,17.15 Z M14.31,15.97 C14.7500022,15.97 15.1016653,15.7533355 15.365,15.32 C15.6283346,14.8866645 15.76,14.2866705 15.76,13.52 C15.76,12.7533295 15.6283346,12.1533355 15.365,11.72 C15.1016653,11.2866645 14.7500022,11.07 14.31,11.07 C13.8699978,11.07 13.5183346,11.2866645 13.255,11.72 C12.9916653,12.1533355 12.86,12.7533295 12.86,13.52 C12.86,14.2866705 12.9916653,14.8866645 13.255,15.32 C13.5183346,15.7533355 13.8699978,15.97 14.31,15.97 Z M7.72890361,4 L9.81373347,6.91876181 L8.18626653,8.08123819 L5.27109639,4 L8.18626653,-0.0812381937 L9.81373347,1.08123819 L7.72890361,4 Z"></path></g></svg>',
                forward:
                    '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-forward" viewBox="0 0 24 24" focusable="false"><g id="forward-10"><path d="M11.8291288,3.00143042 L10.4575629,1.08123819 L12.0850299,-0.0812381937 L15.0002,4 L12.0850299,8.08123819 L10.4575629,6.91876181 L11.8267943,5.0018379 C7.48849327,5.09398699 4,8.63960287 4,13 C4,17.418278 7.581722,21 12,21 C16.418278,21 20,17.418278 20,13 C20,11.4220159 19.5433052,9.91438076 18.6981119,8.6237266 L20.3712764,7.52804389 C21.4281248,9.14190637 22,11.0297737 22,13 C22,18.5228475 17.5228475,23 12,23 C6.4771525,23 2,18.5228475 2,13 C2,7.53422249 6.38510184,3.09264039 11.8291288,3.00143042 Z M8.56,17 L8.56,11.41 L6.9,11.92 L6.9,10.75 L9.88,9.91 L9.88,17 L8.56,17 Z M14.4,17.15 C13.8399972,17.15 13.3500021,17.0016682 12.93,16.705 C12.5099979,16.4083318 12.1850012,15.988336 11.955,15.445 C11.7249989,14.9016639 11.61,14.2600037 11.61,13.52 C11.61,12.786663 11.7249989,12.1466694 11.955,11.6 C12.1850012,11.0533306 12.5099979,10.6316681 12.93,10.335 C13.3500021,10.0383318 13.8399972,9.89 14.4,9.89 C14.9600028,9.89 15.4499979,10.0383318 15.87,10.335 C16.2900021,10.6316681 16.6149988,11.0533306 16.845,11.6 C17.0750012,12.1466694 17.19,12.786663 17.19,13.52 C17.19,14.2600037 17.0750012,14.9016639 16.845,15.445 C16.6149988,15.988336 16.2900021,16.4083318 15.87,16.705 C15.4499979,17.0016682 14.9600028,17.15 14.4,17.15 Z M14.4,15.97 C14.8400022,15.97 15.1916654,15.7533355 15.455,15.32 C15.7183347,14.8866645 15.85,14.2866705 15.85,13.52 C15.85,12.7533295 15.7183347,12.1533355 15.455,11.72 C15.1916654,11.2866645 14.8400022,11.07 14.4,11.07 C13.9599978,11.07 13.6083346,11.2866645 13.345,11.72 C13.0816654,12.1533355 12.95,12.7533295 12.95,13.52 C12.95,14.2866705 13.0816654,14.8866645 13.345,15.32 C13.6083346,15.7533355 13.9599978,15.97 14.4,15.97 Z M14.4575629,6.91876181 L16.5423928,4 L14.4575629,1.08123819 L16.0850299,-0.0812381937 L19.0002,4 L16.0850299,8.08123819 L14.4575629,6.91876181 Z"></path></g></svg>',
            },
            hotstar: {
                rewind: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-rewind" viewBox="0 0 24 24" focusable="false"><path d="M12.436 18.191c.557.595.665 1.564.167 2.215-.522.687-1.469.794-2.114.238a1.52 1.52 0 01-.12-.115l-6.928-7.393a1.683 1.683 0 010-2.271l6.929-7.393a1.437 1.437 0 012.21.093c.521.65.419 1.645-.148 2.25l-5.448 5.814a.55.55 0 000 .743l5.453 5.82h-.001zm4.648-6.563a.553.553 0 000 .744l3.475 3.709a1.683 1.683 0 01-.115 2.382c-.61.532-1.519.418-2.075-.175l-4.828-5.152a1.683 1.683 0 010-2.27l4.888-5.218c.56-.599 1.46-.632 2.056-.074.664.621.632 1.751.007 2.418l-3.409 3.636z" fill-rule="evenodd" clip-rule="evenodd"/></svg>',
                forward: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-forward" viewBox="0 0 24 24" focusable="false"><path d="M11.564 18.19l5.453-5.818a.55.55 0 000-.743l-5.448-5.815c-.567-.604-.67-1.598-.148-2.249.536-.673 1.483-.757 2.115-.186.033.03.065.06.095.093l6.928 7.392a1.683 1.683 0 010 2.272L13.63 20.53a1.439 1.439 0 01-2.125.005 1.588 1.588 0 01-.109-.128c-.498-.65-.39-1.62.166-2.215h.001zm-4.647-6.562L3.508 7.992c-.624-.667-.657-1.797.007-2.418a1.436 1.436 0 012.056.074l4.888 5.217a1.683 1.683 0 010 2.271l-4.827 5.151c-.558.594-1.466.708-2.075.177-.647-.56-.745-1.574-.218-2.262.032-.043.066-.083.103-.122l3.475-3.708a.553.553 0 000-.744z" fill-rule="evenodd" clip-rule="evenodd"/></svg>',
            },
            rewind: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-rewind" viewBox="0 0 1024 1024" focusable="false"><path d="M455.68 262.712889l-67.072 79.644444-206.904889-174.08 56.775111-38.627555a468.48 468.48 0 1 1-201.216 328.817778l103.310222 13.141333a364.487111 364.487111 0 0 0 713.614223 139.605333 364.373333 364.373333 0 0 0-479.971556-435.541333l-14.904889 5.973333 96.312889 81.066667zM329.955556 379.505778h61.610666v308.167111H329.955556zM564.167111 364.088889c61.269333 0 110.933333 45.511111 110.933333 101.717333v135.566222c0 56.149333-49.664 101.660444-110.933333 101.660445s-110.933333-45.511111-110.933333-101.660445V465.749333c0-56.149333 49.664-101.660444 110.933333-101.660444z m0 56.490667c-27.249778 0-49.322667 20.252444-49.322667 45.226666v135.566222c0 24.974222 22.072889 45.169778 49.322667 45.169778 27.192889 0 49.265778-20.195556 49.265778-45.169778V465.749333c0-24.917333-22.072889-45.169778-49.265778-45.169777z" p-id="7377"></path></svg>',
            forward: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-forward" viewBox="0 0 1024 1024" focusable="false"><path d="M561.948444 262.712889l67.015112 79.644444 206.961777-174.08-56.832-38.627555a468.48 468.48 0 1 0 201.216 328.817778l-103.310222 13.141333a364.487111 364.487111 0 0 1-713.557333 139.605333 364.373333 364.373333 0 0 1 479.971555-435.541333l14.904889 5.973333-96.369778 81.066667zM329.955556 379.505778h61.610666v308.167111H329.955556zM564.167111 364.088889c61.269333 0 110.933333 45.511111 110.933333 101.717333v135.566222c0 56.149333-49.664 101.660444-110.933333 101.660445s-110.933333-45.511111-110.933333-101.660445V465.749333c0-56.149333 49.664-101.660444 110.933333-101.660444z m0 56.490667c-27.249778 0-49.322667 20.252444-49.322667 45.226666v135.566222c0 24.974222 22.072889 45.169778 49.322667 45.169778 27.192889 0 49.265778-20.195556 49.265778-45.169778V465.749333c0-24.917333-22.072889-45.169778-49.265778-45.169777z" p-id="7407"></path></svg>',
            download: '<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-download" viewBox="0 0 512 512"><path d="M412.907 214.08C398.4 140.693 333.653 85.333 256 85.333c-61.653 0-115.093 34.987-141.867 86.08C50.027 178.347 0 232.64 0 298.667c0 70.72 57.28 128 128 128h277.333C464.213 426.667 512 378.88 512 320c0-56.32-43.84-101.973-99.093-105.92zM256 384L149.333 277.333h64V192h85.333v85.333h64L256 384z"/></svg>',
        },
        customCSS: "<style>.jwplayer.jw-state-buffering .jw-display-icon-display .jw-icon .jw-svg-icon-buffer{color:" + pConf.playerColor + '!important}.jw-sharing-link:active,.jw-sharing-copy:active.jw-sharing-link:hover,.jw-button-color.jw-toggle.jw-off:active:not(.jw-icon-cast),.jw-button-color.jw-toggle.jw-off:focus:not(.jw-icon-cast),.jw-button-color.jw-toggle.jw-off:hover:not(.jw-icon-cast),.jw-button-color.jw-toggle:not(.jw-icon-cast),.jw-button-color:active:not(.jw-icon-cast),.jw-button-color:focus:not(.jw-icon-cast),.jw-button-color:hover:not(.jw-icon-cast),.jw-button-color[aria-expanded=true]:not(.jw-icon-cast),.jw-settings-content-item.jw-settings-item-active,.jw-settings-menu .jw-icon.jw-button-color[aria-checked="true"] .jw-svg-icon{fill:' + pConf.playerColor + ";color:" + pConf.playerColor + ";background-color:transparent}</style>",
        rewind: function () {
            var seek = 0,
                time = jwp.player.getPosition() - 10;
            if (time > 0) {
                seek = time;
            }
            jwp.player.seek(seek);
        },
        forward: function () {
            var seek = 0,
                time = jwp.player.getPosition() + 10;
            if (time > 0) {
                seek = time;
            }
            jwp.player.seek(seek);
        },
    },
    gdPlyr = {
        container: "#videoContainer",
        player: null,
        hlsjs: null,
        shakaPlayer: null,
        videoType: "mp4",
        sources: [],
        tracks: [],
        config: {
            iconPrefix: "gdp",
            ads: {
                enabled: false,
                tagUrl: "",
            },
            urls: {
                download: "",
            },
            controls: ["play-large", "pause-large", "rewind", "play", "fast-forward", "mute", "volume", "live", "progress", "current-time", "duration"],
            ratio: "16:9",
            autoplay: pConf.autoplay,
            muted: pConf.mute,
            poster: poster,
            loop: {
                active: pConf.repeat,
            },
            captions: {
                active: true,
                update: true,
            },
            tooltips: {
                controls: true,
                seek: true,
            },
            settings: ["quality", "captions"],
            iconUrl: pConf.baseURL + "assets/img/plyr-custom.svg",
            blankVideo: pConf.baseURL + "assets/vendor/plyr/blank.mp4",
            preload: pConf.preload,
        },
        msg: {
            notFound: function () {
                showMessage("Sorry this video is unavailable.");
                gtagReport("video_error", "Sources not found", "plyr", false);
            },
            custom: function (msg) {
                showMessage(msg);
                gtagReport("video_error", msg, "plyr", false);
            },
            timeout: function () {
                showMessage('Connection timed out! <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
                gtagReport("video_error", "Connection timed out", "plyr", false);
            },
            destroy: function (msg) {
                showMessage(msg + ' <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
                gtagReport("video_error", msg, "plyr", false);
            },
        },
        ads: {
            manager: null,
            mute: false,
            fullscreen: false,
            playing: false,
            timer: false,
            createControls: function () {
                var timeRemaining = 0;
                $("body .plyr__ads").append('<div class="plyr__controls"><div class="plyr__custom__controls"><button type="button" id="adsPlay" onclick="gdPlyr.ads.events.togglePlay()" class="plyr__controls__item plyr__control plyr__control--pressed">' + $('button[data-plyr="play"]').html() + '</button><button type="button" id="adsVolume" onclick="gdPlyr.ads.events.toggleMute()" class="plyr__control">' + $('button[data-plyr="mute"]').html() + '</button><div id="adsTimer" class="plyr__controls__item plyr__time--current plyr__time"></div><button type="button" id="adsFullscreen" onclick="gdPlyr.ads.events.toggleFullscreen()" class="plyr__controls__item plyr__control" style="margin-left:auto">' + $('button[data-plyr="fullscreen"]').html() + "</button></div></div>");
                if (gdPlyr.player && typeof gdPlyr.player.ads !== "undefined") {
                    gdPlyr.ads.timer = setInterval(function () {
                        timeRemaining = gdPlyr.config.i18n.advertisement + " - " + prettySecond(Math.floor(gdPlyr.player.ads.manager.getRemainingTime() + 1)).toString();
                        $(".plyr__ads").attr("data-badge-text", timeRemaining);
                        $(".plyr__ads #adsTimer").text(timeRemaining);
                    }, 100);
                }
                $("body .plyr__ads > div:first-child").click(function () {
                    gdPlyr.ads.events.togglePlay();
                });
            },
            removeControls: function () {
                $(".plyr__ads .plyr__controls").remove();
            },
            events: {
                togglePlay: function () {
                    if (gdPlyr.ads.playing) {
                        gdPlyr.player.ads.manager.pause();
                        gdPlyr.ads.playing = false;
                    } else {
                        gdPlyr.player.ads.manager.resume();
                        gdPlyr.ads.playing = true;
                    }
                    $("body #adsPlay").toggleClass("plyr__control--pressed");
                },
                toggleMute: function () {
                    if (gdPlyr.ads.mute) {
                        gdPlyr.ads.mute = false;
                        gdPlyr.player.ads.manager.setVolume(1);
                        gdPlyr.player.muted = false;
                    } else {
                        gdPlyr.ads.mute = true;
                        gdPlyr.player.ads.manager.setVolume(0);
                        gdPlyr.player.muted = true;
                    }
                    $("body #adsVolume").toggleClass("plyr__control--pressed");
                },
                toggleFullscreen: function () {
                    if (gdPlyr.ads.fullscreen) {
                        gdPlyr.ads.fullscreen = false;
                        gdPlyr.player.fullscreen.exit();
                    } else {
                        gdPlyr.ads.fullscreen = true;
                        gdPlyr.player.fullscreen.enter();
                    }
                    $("body #adsFullscreen").toggleClass("plyr__control--pressed");
                },
                completeCallback: function () {
                    $resume.hide();
                    gdPlyr.ads.destroy();
                    gdPlyr.timeChecker();
                },
            },
            initialize: function (p, completeCallback) {
                p.speed = 1;
                p.on("adsloaded", function (e) {
                    $resume.hide();
                    gdPlyr.ads.playing = true;
                    gdPlyr.ads.removeControls();
                    gdPlyr.ads.createControls();
                });
                p.on("adstarted", function (e) {
                    $resume.hide();
                    gdPlyr.ads.playing = true;
                    $("body #adsPlay").addClass("plyr__control--pressed");
                });
                p.on("adscontentresume", function (e) {
                    $resume.hide();
                    p.ads.manager.resume();
                    gdPlyr.ads.playing = true;
                    $("body #adsPlay").addClass("plyr__control--pressed");
                });
                p.on("adscontentpause", function (e) {
                    $resume.hide();
                    p.ads.manager.pause();
                    gdPlyr.ads.playing = false;
                    $("body #adsPlay").removeClass("plyr__control--pressed");
                });
                p.on("adsclick", function (e) {
                    $resume.hide();
                    gdPlyr.ads.playing = false;
                    if ($(".plyr").hasClass("plyr--ad-linear")) {
                        p.ads.manager.pause();
                        gdPlyr.ads.timer = false;
                        clearInterval(gdPlyr.ads.timer);
                        gdPlyr.timeChecker();
                        $("body #adsPlay").removeClass("plyr__control--pressed");
                    } else {
                        $("body .plyr__ads").css("z-index", -1);
                    }
                });
                if (typeof completeCallback !== "undefined") {
                    p.on("adscomplete adsallcomplete adsskip", completeCallback);
                } else {
                    p.on("adscomplete adsallcomplete adsskip", gdPlyr.ads.events.completeCallback);
                }
            },
            destroy: function () {
                var container;
                gdPlyr.config.ads.enabled = false;
                gdPlyr.ads.manager = null;
                gdPlyr.ads.mute = false;
                gdPlyr.ads.fullscreen = false;
                gdPlyr.ads.playing = false;
                clearInterval(gdPlyr.ads.timer);
                gdPlyr.ads.timer = false;
                container = gdPlyr.player.elements.container;
                container.classList.remove("plyr--ad-loaded");
                container.classList.remove("plyr--ad-linear");
                container.classList.remove("plyr--ad-nonlinear");
                container.classList.remove("plyr--hide-controls");
                $("body .plyr__ads").css("z-index", -1);
                gdPlyr.ads.removeControls();
                if (gdPlyr.player.ads.manager) {
                    gdPlyr.player.ads.manager.destroy();
                }
            },
            load: function (initCallback) {
                gdPlyr.player = new Plyr(gdPlyr.container, gdPlyr.config);
                gdPlyr.player.speed = 1;
                gdPlyr.player.source = {
                    type: "video",
                    title: title,
                    sources: [
                        {
                            src: gdPlyr.config.blankVideo,
                        },
                    ],
                };
                gdPlyr.player.poster = poster;
                gdPlyr.player.once("ready", function () {
                    gdPlyr.html.loadCustomHTML();
                });
                gdPlyr.player.once("ended", initCallback);
                gdPlyr.ads.initialize(gdPlyr.player, initCallback);
            },
        },
        destroy: function () {
            if (gdPlyr.hlsjs) {
                gdPlyr.hlsjs.destroy();
                clearInterval(gdPlyr.hlsjs.bufferTimer);
                gdPlyr.hlsjs = null;
            }
            if (gdPlyr.shakaPlayer) {
                gdPlyr.shakaPlayer.detach();
                gdPlyr.shakaPlayer.unload();
                gdPlyr.shakaPlayer.destroy();
                gdPlyr.shakaPlayer = null;
            }
            if (gdPlyr.player) {
                gdPlyr.player.destroy();
                gdPlyr.player = null;
            }
        },
        adblocker: function (blocked) {
            setTimeout(function () {
                if (pConf.blockADB && (blocked || !canRunAds)) {
                    gdPlyr.destroy();
                    adblockerMessage();
                } else {
                    loadSources(
                        function (res) {
                            var $next,
                                link = "",
                                $servers = $("#servers li"),
                                serverLen = $servers.length;
                            if (res.status !== "fail") {
                                title = res.title;
                                poster = res.poster;
                                gdPlyr.tracks = res.tracks;
                                if ("filmstrip" in res && res.filmstrip !== "") {
                                    gdPlyr.config.previewThumbnails = {
                                        enabled: true,
                                        src: res.filmstrip,
                                    };
                                }
                                if (res.sources.length > 0) {
                                    gdPlyr.sources = res.sources;
                                    gdPlyr.videoType = res.sources[0].type;
                                    gdPlyr.init();
                                } else {
                                    gdPlyr.msg.notFound();
                                }
                            } else if (serverLen > 1) {
                                $servers.each(function (i, e) {
                                    if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                                        $next = $(this).next();
                                        if ($next.length > 0) {
                                            link = $next.find("a").attr("href");
                                            return true;
                                        }
                                    }
                                });
                                if (link !== "") {
                                    window.location.href = link;
                                } else {
                                    showMessage(res.message);
                                }
                            } else {
                                retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                                if (retryNumber < 3) {
                                    retry(retryNumber);
                                } else {
                                    gdPlyr.msg.custom(res.message);
                                }
                            }
                        },
                        function (xhr, status) {
                            if (status === "timeout") {
                                gdPlyr.msg.timeout();
                            } else {
                                failed();
                            }
                        }
                    );
                }
            }, 300);
        },
        init: function () {
            var lang = window.navigator.languages ? window.navigator.languages[0] : "en";
            lang = lang || window.navigator.language || window.navigator.browserLanguage || window.navigator.userLanguage;
            $.ajax({
                url: pConf.baseURL + "assets/vendor/plyr/translations/" + lang.substring(0, 2) + ".json",
                dataType: "json",
                timeout: 60000,
                success: function (res) {
                    gdPlyr.config.i18n = res;
                    gdPlyr.loadPlayer();
                },
                error: function () {
                    gdPlyr.loadPlayer();
                },
            });
        },
        loadPlayer: function () {
            EncryptionSchemePolyfills.install();
            shaka.polyfill.installAll();
            if (gdPlyr.videoType === "hls") {
                gdPlyr.hls.load(gdPlyr.sources[0].file);
            } else if (gdPlyr.videoType === "mpd") {
                gdPlyr.mpd.load(gdPlyr.sources[0].file);
            } else if (gdPlyr.videoType.indexOf("mp4") > -1) {
                gdPlyr.mp4.load(gdPlyr.sources);
            } else {
                gdPlyr.msg.custom("This browser is not supported. " + navigator.userAgent);
            }
        },
        html: {
            qualityInterval: null,
            qualityButton: 'body button[data-plyr="quality"]',
            autoButton: 'body button[data-plyr="quality"][value="0"]',
            autoSpan: 'body button[data-plyr="quality"][value="0"] span',
            loadTitle: function ($plyr, titleStyle) {
                $plyr.append('<div class="plyr-title" style="' + titleStyle + '">' + title + "</div>");
            },
            loadCustomHTML: function () {
                var titleStyle = [],
                    $this = $(".plyr"),
                    $video = $this.find("video"),
                    logoPos = pConf.logoPosition,
                    logoImg = pConf.logoImage,
                    logoMargin = pConf.logoMargin,
                    $logo = $('<a class="plyr-logo plyr-logo-' + logoPos + " " + (pConf.logoHide ? "plyr-logo-hide" : "") + '" href="' + pConf.logoLink + '" target="_blank"></a>'),
                    $img = $('<img alt="Logo" />'),
                    $controls = $(".plyr__controls"),
                    $customControls = $('<div class="plyr__custom__controls"></div>'),
                    seektime = gdPlyr.config.seekTime,
                    rewindText = gdPlyr.config.i18n.rewind.replace("{seektime}", seektime),
                    forwardText = gdPlyr.config.i18n.fastForward.replace("{seektime}", seektime);
                $controls.append($customControls);
                $customControls.append($(".plyr__controls > *"));
                $controls.prepend($customControls.find(".plyr__progress__container"));
                $("head").append("<style>::cue,video::cue{opacity:0!important}</style>");
                if (logoImg !== "") {
                    if (logoPos.indexOf("top-left") > -1) {
                        titleStyle.push("left:");
                    } else if (logoPos.indexOf("top-right") > -1) {
                        titleStyle.push("margin-right:");
                    }
                    $this.append($logo);
                    $logo.append($img);
                    $img.attr("src", logoImg).on("load", function (e) {
                        titleStyle.push(e.currentTarget.width + logoMargin);
                        titleStyle.push("px");
                        if (pConf.displayTitle) {
                            gdPlyr.html.loadTitle($this, titleStyle.join(""));
                        }
                    });
                } else if (pConf.displayTitle) {
                    gdPlyr.html.loadTitle($this, titleStyle.join(""));
                }
                $video.attr("poster", poster);
                $video.addClass("plyr-stretch-" + pConf.stretching);
                $("a[data-plyr=download]").removeAttr("download");
                if (navigator.userAgent.indexOf("Trident/") > -1 && navigator.userAgent.indexOf("Edg/") === -1) {
                    $(".plyr__captions").hide();
                }
                $("body .plyr__control--overlaid").html($('button[data-plyr="play"]').html());
                $("body .plyr__control--overlaid")
                    .before('<button type="button" class="plyr__control plyr__control--overlaid" data-plyr="rewind" aria-label="' + rewindText + '" onclick="gdPlyr.player.rewind()">' + $('button[data-plyr="rewind"]').html() + "</button>")
                    .after('<button type="button" class="plyr__control plyr__control--overlaid" data-plyr="fast-forward" aria-label="' + forwardText + '" onclick="gdPlyr.player.forward()">' + $('button[data-plyr="fast-forward"]').html() + "</button>");
                gdPlyr.mediaSession.load();
                gtagReport("video_ready_to_play", "Ready To Play", "plyr", false);
                showPlayer();
            },
            loadExternalTracks: function () {
                var length = gdPlyr.tracks.length,
                    textTracks = [],
                    loadTimeout;
                if (length > 0) {
                    $.each(gdPlyr.tracks, function (i, e) {
                        $(".plyr video" + gdPlyr.container).append('<track kind="captions" src="' + e.file.replace("https:", "").replace("http:", "") + '" label="' + e.label + '">');
                    });
                    loadTimeout = setTimeout(function () {
                        textTracks = document.querySelector(gdPlyr.container).textTracks;
                        if (textTracks.length > 0) {
                            textTracks[0].mode = "showing";
                            gdPlyr.player.currentTrack = 0;
                            clearTimeout(loadTimeout);
                        }
                    }, 300);
                }
            },
            loadAudio: function (audioDefault, audioButtons, clickCallback) {
                var menuId = $(".plyr__menu__container").attr("id").replace("plyr-settings-", ""),
                    menuItem = "plyr-settings-" + menuId,
                    audioMenu = menuItem + "-audio",
                    audioText = gdPlyr.player.config.i18n.audio,
                    $homeSetting = $("#" + menuItem + "-home");

                $homeSetting.find("div[role=menu]").prepend('<button id="btnAudio" data-plyr="settings" type="button" class="plyr__control plyr__control--forward" role="menuitem" aria-haspopup="true"><span>' + audioText + '<span class="plyr__menu__value">' + audioDefault + "</span></span></button>");

                $homeSetting.after('<div id="' + audioMenu + '" hidden><button type="button" class="plyr__control plyr__control--back"><span aria-hidden="true">' + audioText + '</span><span class="plyr__sr-only">Go back to previous menu</span></button><div role="menu">' + audioButtons + "</div></div>");

                $("button#btnAudio").click(function () {
                    $("#" + audioMenu).prop("hidden", false);
                    $homeSetting.prop("hidden", true);
                });

                $("#" + audioMenu + " .plyr__control--back").click(function () {
                    $("#" + audioMenu).prop("hidden", true);
                    $homeSetting.prop("hidden", false);
                });

                $('button[data-plyr="audio"]').click(function () {
                    clickCallback($(this).val());
                    $('button[data-plyr="audio"]').attr("aria-checked", "false");
                    $(this).attr("aria-checked", "true");
                    $("button#btnAudio")
                        .find(".plyr__menu__value")
                        .text($(this).text().replace($(this).find(".plyr__badge").text(), "").trim());
                    $("#" + audioMenu).prop("hidden", true);
                    $homeSetting.prop("hidden", false);
                });
            },
            updateQualityMenuItem: function (selected) {
                var auto = gdPlyr.config.i18n.auto,
                    height = "",
                    $menuQuality = $('body button[data-plyr="settings"]:contains("' + gdPlyr.config.i18n.quality + '") > span > span'),
                    $auto = $(gdPlyr.html.autoSpan);
                $auto.text(auto);
                $menuQuality.text(auto);
                if (Number(selected) > -1) {
                    if (gdPlyr.hlsjs) {
                        height = gdPlyr.hlsjs.levels[selected].height;
                    } else if (gdPlyr.shakaPlayer) {
                        height = gdPlyr.shakaPlayer.getVariantTracks()[selected].height;
                    }
                    if (height !== "") {
                        $menuQuality.text(height + "p");
                    }
                }
            },
        },
        events: {
            timeupdate: function () {
                var time = Math.round(gdPlyr.player.currentTime),
                    dur = Math.round(gdPlyr.player.duration);
                latestPlayTime = Math.round(xStorage.getItem(latestPlayKey));
                if (time > gdPlyr.hls.currentTime) {
                    gdPlyr.hls.currentTime = time;
                }
                if (time > 0 && time > latestPlayTime) {
                    xStorage.setItem(latestPlayKey, time);
                    xStorage.removeItem(retryKey);
                }
                if (time >= pConf.statCounterRuntime && !statCounted) {
                    statCounter();
                }
                if (gdPlyr.player.source.indexOf("/mpegts/") > -1 && time === dur && dur > 0) {
                    gdPlyr.loadPlayer();
                }
            },
            play: function () {
                visitDirectAds();
                xStorage.removeItem("autoplay");
            },
            enterfullscreen: function () {
                $(".plyr__video-wrapper").attr("style", "");
                $(".plyr video" + gdPlyr.container)
                    .css("position", "absolute")
                    .css("top", 0)
                    .css("bottom", 0);
                $(document).find("#adsFullscreen").addClass("plyr__control--pressed");
            },
            exitfullscreen: function () {
                $(document).find("#adsFullscreen").removeClass("plyr__control--pressed");
            },
            ended: function () {
                if (statLogInterval) {
                    clearInterval(statLogInterval);
                    statLogInterval = false;
                }
                xStorage.removeItem(latestPlayKey);
                gtagReport("video_complete", "Playback Has Ended", "plyr", false);
            },
            error: function (e) {
                var $next,
                    link = "",
                    $servers = $("#servers li"),
                    serverLen = $servers.length,
                    err = e.detail.plyr.media.error;
                if (err) {
                    showLoading();
                    if (serverLen > 1) {
                        $servers.each(function (i, e) {
                            if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                                $next = $(this).next();
                                if ($next.length > 0) {
                                    link = $next.find("a").attr("href");
                                    return true;
                                }
                            }
                        });
                        if (link !== "") {
                            window.location.href = link;
                        } else if (err && "message" in err) {
                            gdPlyr.msg.custom(err.message);
                        } else {
                            showPlayer();
                        }
                    } else {
                        retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                        if (retryNumber < 3) {
                            retry(retryNumber);
                        } else {
                            showPlayer();
                        }
                    }
                } else {
                    showPlayer();
                }
            },
        },
        timeChecker: function () {
            var timeFormat = "";
            if (!isLive && pConf.resumePlayback) {
                latestPlayTime = xStorage.getItem(latestPlayKey);
                if (latestPlayTime && $resume.length && gdPlyr.player.currentTime < Number(latestPlayTime)) {
                    timeFormat = prettySecond(latestPlayTime);
                    $timez.text(timeFormat);
                    $myConfirm.text($myConfirm.text().replace("hh:mm:ss", timeFormat));
                    $resume.show();
                }
            }
        },
        resumePlayback: function () {
            $resume.hide();
            gdPlyr.player.currentTime = Math.floor(xStorage.getItem(latestPlayKey));
            gdPlyr.player.play();
        },
        codecsIsSupported: function (codecs) {
            var result = false;
            try {
                result = MediaSource.isTypeSupported('video/mp4;codecs="' + codecs + '"');
            } catch (e) {}
            return result;
        },
        shortQualities: function (a, b) {
            var x = a.toString().split("."),
                y = b.toString().split(".");
            if (Number(x[0]) === Number(y[0])) {
                return Number(x[1]) - Number(y[1]);
            } else {
                return Number(x[0]) - Number(y[0]);
            }
        },
        mp4: {
            parser: function () {
                var newSources = [],
                    sizes = [],
                    size = 0,
                    sources = gdPlyr.sources,
                    length = sources.length;
                if (length > 0) {
                    $.each(sources, function (i, e) {
                        if (e.label !== "Default" && e.label !== "Original") {
                            size = Number(e.label.replace("p", ""));
                            sizes.push(size);
                            newSources.push({
                                src: e.file,
                                type: e.type,
                                size: size,
                            });
                        }
                    });
                    if (newSources.length === 0) {
                        sizes.push(360);
                        newSources.push({
                            src: sources[0].file,
                            type: sources[0].type,
                            size: 360,
                        });
                    }
                }
                return {
                    sources: newSources,
                    sizes: sizes,
                };
            },
            load: function () {
                var newTracks = [],
                    parser = gdPlyr.mp4.parser(),
                    selectedResolution = 360,
                    label = 360,
                    kindAttr = "captions",
                    defaultAttr = false;
                gdPlyr.destroy();
                $.each(gdPlyr.tracks, function (i, e) {
                    if ("kind" in e) {
                        kindAttr = e.kind;
                    }
                    defaultAttr = "default" in e && e.default;
                    newTracks.push({
                        src: e.file,
                        label: e.label,
                        kind: kindAttr,
                        default: defaultAttr,
                    });
                });
                $.each(parser.sizes, function (i, e) {
                    if (e >= 100 && e < 200) label = 100;
                    else if (e >= 200 && e < 300) label = 200;
                    else if (e >= 300 && e < 400) label = 300;
                    else if (e >= 400 && e < 500) label = 400;
                    else if (e >= 500 && e < 600) label = 500;
                    else if (e >= 600 && e < 700) label = 600;
                    else if (e >= 700 && e < 800) label = 700;
                    else if (e >= 800 && e < 900) label = 800;
                    else if (e >= 900 && e < 1000) label = 900;
                    else if (e >= 1000) label = 1000;
                    if (label === pConf.defaultResolution) {
                        selectedResolution = e;
                    }
                });
                gdPlyr.config.quality = {
                    default: selectedResolution,
                    options: parser.sizes,
                    forced: true,
                };
                gdPlyr.player = new Plyr(gdPlyr.container, gdPlyr.config);
                gdPlyr.player.speed = 1;
                gdPlyr.player.source = {
                    type: "video",
                    title: title,
                    sources: parser.sources,
                    tracks: newTracks,
                };
                gdPlyr.player.once("ready", function () {
                    isLive = false;
                    gdPlyr.html.loadCustomHTML();
                });
                gdPlyr.player.once("loadedmetadata", function (e) {
                    gdPlyr.player.currentTrack = 0;
                    gdPlyr.timeChecker();
                });
                gdPlyr.player.once("play", gdPlyr.events.play);
                gdPlyr.player.once("ended", gdPlyr.events.ended);
                gdPlyr.player.once("error", gdPlyr.events.error);
                gdPlyr.player.on("timeupdate", gdPlyr.events.timeupdate);
                gdPlyr.player.on("enterfullscreen", gdPlyr.events.enterfullscreen);
                gdPlyr.player.on("exitfullscreen", gdPlyr.events.exitfullscreen);
                gdPlyr.ads.initialize(gdPlyr.player, function () {
                    gdPlyr.ads.events.completeCallback();
                    gdPlyr.player.play();
                });
            },
        },
        hls: {
            currentTime: 0,
            audioGroupSelected: undefined,
            audioSelected: undefined,
            audioTracksAllowed: [],
            selectedTrack: -1,
            levelsAllowed: [],
            levelsSelector: [0],
            config: {
                debug: true,
                defaultAudioCodec: "mp4a.40.2",
                startFragPrefetch: true,
                capLevelToPlayerSize: true,
                capLevelOnFPSDrop: true,
            },
            loadAudio: function () {
                var audioTracks = gdPlyr.hlsjs.audioTrackController.tracks,
                    audioDefault = "",
                    audioChecked = "false",
                    audioButtons = "";
                if (typeof audioTracks !== "undefined" && audioTracks.length > 1) {
                    $.each(audioTracks, function (i, e) {
                        if (typeof e.groupId !== "undefined" && (e.groupId === gdPlyr.hls.audioGroupSelected || typeof e.audioCodec === "undefined")) {
                            if (e.default && audioDefault === "") {
                                audioDefault = e.name;
                                audioChecked = "true";
                            } else {
                                audioChecked = "false";
                            }
                            audioButtons += '<button data-plyr="audio" type="button" role="menuitemradio" class="plyr__control" aria-checked="' + audioChecked + '" value="' + e.id + '"><span>' + e.name + (typeof e.lang !== "undefined" ? '<span class="plyr__menu__value"><span class="plyr__badge">' + e.lang.toUpperCase() + "</span></span>" : "") + "</span></button>";
                        }
                    });
                    gdPlyr.html.loadAudio(audioDefault, audioButtons, function (id) {
                        gdPlyr.hls.audioSelected = id;
                        gdPlyr.hlsjs.audioTrack = id;
                    });
                }
            },
            levelUpdated: function (e, d) {
                if (d.level > -1 && gdPlyr.hls.levelsAllowed.indexOf(d.level) === -1) {
                    gdPlyr.hlsjs.stopLoad();
                    gdPlyr.hlsjs.removeLevel(d.level);
                    gdPlyr.hlsjs.swapAudioCodec();
                    gdPlyr.hlsjs.recoverMediaError();
                    gdPlyr.hlsjs.startLoad(gdPlyr.hls.currentTime);
                }
                gdPlyr.html.updateQualityMenuItem(gdPlyr.hlsjs.currentLevel);
            },
            load: function (source, reload) {
                var p2pEngine,
                    quality,
                    bitrate,
                    textTracks,
                    levelSelected = -1,
                    i,
                    codecs = [],
                    codecsSupported = [];
                gdPlyr.destroy();
                if (gdPlyr.config.ads.enabled && typeof reload === "undefined") {
                    gdPlyr.ads.load(function () {
                        gdPlyr.ads.events.completeCallback();
                        gdPlyr.hls.load(source, true);
                    });
                } else {
                    showLoading();
                    gdPlyr.config.source = {
                        type: "hls",
                        src: source,
                    };
                    gdPlyr.hls.config.debug = pConf.productionMode ? false : true;
                    if ("configure" in pConf) {
                        $.extend({}, gdPlyr.hls.config, pConf.configure);
                    }
                    if (p2pEnabled) {
                        if (typeof gdPlyr.hls.config.xhrSetup !== "undefined") {
                            p2pConfig.loader.xhrSetup = gdPlyr.hls.config.xhrSetup;
                        }
                        p2pEngine = new p2pml.hlsjs.Engine(p2pConfig);
                        gdPlyr.hls.config.liveSyncDurationCount = 7;
                        gdPlyr.hls.config.loader = p2pEngine.createLoaderClass();
                    }
                    for (i in AUDIO_CODECS) {
                        if (gdPlyr.codecsIsSupported(AUDIO_CODECS[i].codec)) {
                            codecs.push(AUDIO_CODECS[i].codec);
                        }
                    }
                    codecsSupported = codecs.filter(function (e) {
                        return e.indexOf("mp4a") > -1;
                    });
                    if (codecsSupported.length === 0) {
                        codecsSupported = codecs;
                    }
                    gdPlyr.hlsjs = new Hls(gdPlyr.hls.config);
                    if (p2pEnabled) {
                        p2pml.hlsjs.initHlsJsPlayer(gdPlyr.hlsjs);
                    }
                    gdPlyr.hlsjs.attachMedia(document.querySelector(gdPlyr.container));
                    gdPlyr.hlsjs.on(Hls.Events.MEDIA_ATTACHED, function (e, d) {
                        gdPlyr.hlsjs.loadSource(gdPlyr.config.source.src);
                    });
                    gdPlyr.hlsjs.on(Hls.Events.MANIFEST_PARSED, function (e, d) {
                        if (d.levels.length > 0 && gdPlyr.hls.levelsAllowed.length === 0) {
                            $.each(d.levels, function (i, e) {
                                if ((codecsSupported.indexOf(e.audioCodec) > -1 || typeof e.audioCodec === "undefined") && (gdPlyr.codecsIsSupported(e.videoCodec) || typeof e.videoCodec === "undefined")) {
                                    if (typeof gdPlyr.hls.audioGroupSelected === "undefined" && typeof e.audioGroupIds !== "undefined") {
                                        gdPlyr.hls.audioGroupSelected = e.audioGroupIds[0];
                                    }
                                    if (typeof gdPlyr.hls.textGroupSelected === "undefined" && typeof e.textGroupIds !== "undefined") {
                                        gdPlyr.hls.textGroupSelected = e.textGroupIds[0];
                                    }
                                    if ("bitrate" in e) {
                                        bitrate = e.bitrate.toString();
                                    }
                                    if ("height" in e) {
                                        quality = e.height.toString();
                                    }
                                    gdPlyr.hls.levelsSelector.push(quality + "." + bitrate);
                                    gdPlyr.hls.levelsAllowed.push(i);
                                }
                            });
                            if (gdPlyr.hls.levelsAllowed.length === 0) {
                                $.each(d.levels, function (i, e) {
                                    gdPlyr.hls.levelsAllowed.push(i);
                                });
                            }
                        }
                        if (gdPlyr.hls.levelsAllowed.length > 0) {
                            levelSelected = gdPlyr.hls.levelsAllowed[gdPlyr.hls.levelsAllowed.length - 1];
                            gdPlyr.hlsjs.firstLevel = levelSelected;
                            gdPlyr.hlsjs.startLevel = levelSelected;
                            gdPlyr.hlsjs.currentLevel = levelSelected;
                        }
                        gdPlyr.html.updateQualityMenuItem(gdPlyr.hlsjs.currentLevel);
                        if (gdPlyr.hls.currentTime > 0) {
                            gdPlyr.hlsjs.startLoad(gdPlyr.hls.currentTime);
                        }
                        if (d.audio && d.audioTracks.length > 0 && gdPlyr.hls.audioTracksAllowed.length === 0) {
                            $.each(d.audioTracks, function (i, e) {
                                if (e.groupId === gdPlyr.hls.audioGroupSelected) {
                                    gdPlyr.hls.audioTracksAllowed.push(e);
                                }
                            });
                            if (gdPlyr.hls.audioTracksAllowed.length > 0) {
                                gdPlyr.hls.audioSelected = gdPlyr.hls.audioTracksAllowed[0].id;
                                gdPlyr.hlsjs.audioTrack = gdPlyr.hls.audioTracksAllowed[0].id;
                            }
                        }
                        if (typeof gdPlyr.hls.audioSelected !== "undefined") {
                            gdPlyr.hlsjs.audioTrack = gdPlyr.hls.audioSelected;
                        }
                        if (gdPlyr.hls.levelsSelector.length > 2 && typeof gdPlyr.config.quality === "undefined") {
                            gdPlyr.hls.levelsSelector.sort(gdPlyr.shortQualities);
                            gdPlyr.config.quality = {
                                default: 0,
                                options: gdPlyr.hls.levelsSelector,
                                forced: true,
                                onChange: function (selected) {
                                    var split = [];
                                    $(gdPlyr.html.autoSpan).text(gdPlyr.config.i18n.auto);
                                    if (typeof selected === "number") {
                                        gdPlyr.hlsjs.currentLevel = -1;
                                        selected = gdPlyr.hlsjs.currentLevel;
                                    } else {
                                        split = selected.split(".");
                                        selected = gdPlyr.hlsjs.levels.findIndex(function (e) {
                                            return e.height === Number(split[0]) && e.bitrate === Number(split[1]);
                                        });
                                        gdPlyr.hlsjs.currentLevel = selected;
                                    }
                                    gdPlyr.html.updateQualityMenuItem(selected);
                                },
                            };
                        }
                        if (!gdPlyr.player) {
                            gdPlyr.player = new Plyr(gdPlyr.container, gdPlyr.config);
                            gdPlyr.player.speed = 1;
                        }
                        gdPlyr.player.poster = poster;
                        gdPlyr.player.once("play", gdPlyr.events.play);
                        gdPlyr.player.once("ended", gdPlyr.events.ended);
                        gdPlyr.player.on("timeupdate", gdPlyr.events.timeupdate);
                        gdPlyr.player.on("enterfullscreen", gdPlyr.events.enterfullscreen);
                        gdPlyr.player.on("exitfullscreen", gdPlyr.events.exitfullscreen);
                        gdPlyr.player.on("ready", function (e) {
                            gdPlyr.html.loadCustomHTML();
                            gdPlyr.hls.loadAudio();
                            gdPlyr.timeChecker();
                            if (typeof reload !== "undefined") {
                                e.detail.plyr.elements.container.classList.add("plyr--loading");
                            }
                            levelSelected = gdPlyr.hlsjs.levels[0];
                            isLive = typeof levelSelected.details !== "undefined" && "live" in levelSelected.details && levelSelected.details.live;
                            if (isLive) {
                                $(".plyr").addClass("plyr--live");
                            } else {
                                $(".plyr").removeClass("plyr--live");
                            }
                            textTracks = document.querySelector(gdPlyr.container).textTracks;
                            if (textTracks.length === 0) {
                                gdPlyr.html.loadExternalTracks();
                            } else {
                                textTracks.forEach(function (e, i) {
                                    if (e.mode === "showing") {
                                        gdPlyr.player.currentTrack = i;
                                    }
                                });
                            }
                            gdPlyr.html.updateQualityMenuItem(gdPlyr.hlsjs.currentLevel);
                        });
                        gdPlyr.player.on("loadedmetadata", function (e) {
                            if (typeof reload !== "undefined") {
                                gdPlyr.player.play();
                            }
                        });
                        gdPlyr.player.on("languagechange captionsenabled", function (e) {
                            var index = gdPlyr.player.currentTrack;
                            textTracks = document.querySelector(gdPlyr.container).textTracks;
                            if (textTracks.length > 0) {
                                textTracks.forEach(function (e, i) {
                                    e.mode = "hidden";
                                });
                                gdPlyr.hlsjs.subtitleTrack = index;
                            }
                        });
                    });
                    gdPlyr.hlsjs.on(Hls.Events.LEVEL_UPDATED, gdPlyr.hls.levelUpdated);
                    gdPlyr.hlsjs.on(Hls.Events.LEVEL_SWITCHED, gdPlyr.hls.levelUpdated);
                    gdPlyr.hlsjs.on(Hls.Events.LEVEL_LOADED, gdPlyr.hls.levelUpdated);
                    gdPlyr.hlsjs.on(Hls.Events.LEVEL_PTS_UPDATED, gdPlyr.hls.levelUpdated);
                    gdPlyr.hlsjs.on(Hls.Events.ERROR, function (e, d) {
                        if (d.fatal) {
                            var $next,
                                link = "",
                                $servers = $("#servers li"),
                                serverLen = $servers.length;
                            showLoading();
                            if (serverLen > 1) {
                                $servers.each(function (i, e) {
                                    if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                                        $next = $(this).next();
                                        if ($next.length > 0) {
                                            link = $next.find("a").attr("href");
                                            return true;
                                        }
                                    }
                                });
                                if (link !== "") {
                                    window.location.href = link;
                                } else if (d.error && "message" in d.error) {
                                    gdPlyr.msg.custom("HLS.js Error! " + d.error.message);
                                } else {
                                    failed();
                                }
                            } else {
                                retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                                if (retryNumber < 3) {
                                    retry(retryNumber);
                                } else {
                                    failed();
                                }
                            }
                        }
                    });
                }
            },
        },
        mpd: {
            startTrackValue: -1,
            selectTrack: function (selected) {
                var $subtitle = $(".plyr__menu__container [data-plyr='language'][value='" + selected + "']"),
                    $div = $(".plyr__menu__container > div > div"),
                    $home;
                $(".plyr__menu__container [data-plyr='language']").attr("aria-checked", "false");
                if ($subtitle.text().indexOf("Shaka Player") > -1) {
                    $subtitle = $subtitle.next();
                }
                $subtitle.attr("aria-checked", "true");
                $div.each(function (i, e) {
                    if ($(this).attr("id").indexOf("home") > -1) {
                        $home = $(this);
                        return false;
                    }
                });
                $home.find('button[data-plyr="settings"]').each(function (i, e) {
                    if ($(this).text().indexOf(gdPlyr.config.i18n.captions) > -1) {
                        $(this)
                            .find(".plyr__menu__value")
                            .text($subtitle.text().replace($subtitle.find(".plyr__menu__value").text(), ""));
                        return false;
                    }
                });
            },
            errorHandler: function (e) {
                var $next,
                    link = "",
                    $servers = $("#servers li"),
                    serverLen = $servers.length,
                    err;
                showLoading();
                if (serverLen > 1) {
                    $servers.each(function (i, e) {
                        if ($(this).find("a").hasClass("active") && i < serverLen - 1) {
                            $next = $(this).next();
                            if ($next.length > 0) {
                                link = $next.find("a").attr("href");
                                return true;
                            }
                        }
                    });
                    if (link !== "") {
                        window.location.href = link;
                    } else if (typeof err !== "undefined" && "name" in err && "description" in err) {
                        $("#message").css("font-size", "16px");
                        gdPlyr.msg.custom("ShakaPlayer.js Error! " + err.name + ", " + err.description);
                    } else {
                        showPlayer();
                    }
                } else {
                    retryNumber = retryNumber ? Number(retryNumber) + 1 : 0;
                    if (retryNumber < 3) {
                        retry(retryNumber);
                    } else if ("message" in e) {
                        gdPlyr.msg.custom(e.message);
                    } else {
                        err = gdPlyr.mpd.errorDetail(e.code);
                        $("#message").css("font-size", "16px");
                        gdPlyr.msg.custom("ShakaPlayer.js Error! " + err.name + ", " + err.description);
                    }
                }
            },
            errorDetail: function (code) {
                if (code && shakaErrorCodes) {
                    return shakaErrorCodes.find(function (obj) {
                        return obj.code === code;
                    });
                }
                return {
                    code: undefined,
                    name: "Browser Error",
                    description: "Failed to init decoder",
                };
            },
            getDefaultConfig: function () {
                var config = {
                    abr: {
                        enabled: true,
                    },
                    manifest: {
                        dash: {
                            autoCorrectDrift: true,
                            ignoreEmptyAdaptationSet: true,
                        },
                    },
                    streaming: {
                        rebufferingGoal: 0.01,
                    },
                };
                if ("configure" in pConf) {
                    $.extend({}, config, pConf.configure);
                }
                return config;
            },
            qualityChange: function (selected) {
                var shakaConfig = gdPlyr.mpd.getDefaultConfig(),
                    variantTracks = gdPlyr.shakaPlayer.getVariantTracks();
                if (Number(selected) === 0) {
                    shakaConfig.abr.enabled = true;
                    gdPlyr.shakaPlayer.configure(shakaConfig);
                } else {
                    shakaConfig.abr.enabled = false;
                    selected = selected.split(".");
                    selected = variantTracks.findIndex(function (e) {
                        return e.type === "variant" && e.height === Number(selected[0]) && e.bandwidth === Number(selected[1]) && e.language === selected[2];
                    });
                    gdPlyr.shakaPlayer.configure(shakaConfig);
                    gdPlyr.shakaPlayer.selectVariantTrack(variantTracks[selected], true);
                }
                gdPlyr.html.updateQualityMenuItem(selected);
            },
            loadAudio: function () {
                var variantTracks = gdPlyr.shakaPlayer.getVariantTracks(),
                    audioTracks = [],
                    audioDefault = "",
                    audioLabel = "",
                    audioChecked = "false",
                    audioButtons = "",
                    qualitySelected,
                    shakaConfig = gdPlyr.mpd.getDefaultConfig();
                $(gdPlyr.html.autoSpan).text(gdPlyr.config.i18n.auto);
                if (typeof variantTracks !== "undefined") {
                    $.each(variantTracks, function (i, e) {
                        if (audioTracks.length === 0 || audioTracks.indexOf(e.language) === -1) {
                            if ((e.active || i === 0) && audioDefault === "") {
                                audioDefault = e.language;
                                audioChecked = "true";
                            } else {
                                audioChecked = "false";
                            }
                            audioLabel = e.label ? e.label : e.language;
                            audioTracks.push(e.language);
                            audioButtons += '<button data-plyr="audio" type="button" role="menuitemradio" class="plyr__control" aria-checked="' + audioChecked + '" value="' + e.language + '"><span>' + audioLabel + '<span class="plyr__menu__value"><span class="plyr__badge">' + e.language.toUpperCase() + "</span></span>" + "</span></button>";
                        }
                    });
                    if (audioTracks.length > 1) {
                        gdPlyr.mpd.audioSelected(audioDefault);
                        gdPlyr.html.loadAudio(audioDefault, audioButtons, function (language) {
                            gdPlyr.mpd.audioSelected(language);
                            qualitySelected = variantTracks.find(function (e) {
                                return e.type === "variant" && e.language === language;
                            });
                            if (qualitySelected) {
                                shakaConfig.abr.enabled = false;
                                gdPlyr.shakaPlayer.configure(shakaConfig);
                                gdPlyr.shakaPlayer.selectVariantTrack(qualitySelected, true);
                            }
                        });
                    }
                }
            },
            audioSelected: function (language) {
                $(gdPlyr.html.qualityButton).each(function (i, e) {
                    if (
                        $(this)
                            .val()
                            .indexOf("." + language) > -1 ||
                        $(this).val() === "0"
                    ) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            },
            load: function (source, reload) {
                var shakaConfig = gdPlyr.mpd.getDefaultConfig(),
                    p2pEngine,
                    qualitySelector = [0],
                    quality,
                    variantSelected,
                    bandwidth = 0,
                    variantTracks,
                    textTracks = [],
                    $video,
                    addTextTrack;
                gdPlyr.destroy();
                if (gdPlyr.config.ads.enabled && typeof reload === "undefined") {
                    gdPlyr.ads.load(function () {
                        gdPlyr.ads.events.completeCallback();
                        gdPlyr.mpd.load(source, true);
                    });
                } else {
                    showLoading();
                    gdPlyr.config.source = {
                        type: "mpd",
                        src: source,
                    };
                    if (!p2pEnabled) {
                        shakaConfig.streaming = {
                            lowLatencyMode: true,
                            inaccurateManifestTolerance: 0,
                            rebufferingGoal: 0.01,
                        };
                    }
                    if (!pConf.productionMode) {
                        shaka.log.setLevel(shaka.log.Level.V2);
                    }
                    gdPlyr.shakaPlayer = new shaka.Player(document.querySelector(gdPlyr.container));
                    gdPlyr.shakaPlayer.configure(shakaConfig);
                    if (p2pEnabled) {
                        p2pEngine = new p2pml.shaka.Engine(p2pConfig);
                        p2pEngine.initShakaPlayer(gdPlyr.shakaPlayer);
                    }
                    if ("registerRequestFilter" in pConf) {
                        gdPlyr.shakaPlayer.getNetworkingEngine().registerRequestFilter(pConf.registerRequestFilter);
                    }
                    gdPlyr.shakaPlayer
                        .load(gdPlyr.config.source.src)
                        .then(function () {
                            variantTracks = gdPlyr.shakaPlayer.getVariantTracks();
                            textTracks = gdPlyr.shakaPlayer.getTextTracks();
                            $.each(variantTracks, function (i, e) {
                                if ("bandwidth" in e) {
                                    bandwidth = e.bandwidth;
                                }
                                if ("height" in e) {
                                    quality = e.height;
                                }
                                qualitySelector.push(quality + "." + bandwidth + "." + e.language);
                            });
                            if (qualitySelector.length > 2) {
                                qualitySelector.sort(gdPlyr.shortQualities);
                                gdPlyr.config.quality = {
                                    default: 0,
                                    options: qualitySelector,
                                    forced: true,
                                };
                                gdPlyr.mpd.qualityChange(0);
                            }
                            $video = document.querySelector("video#videoContainer");
                            if (textTracks.length > 0) {
                                $.each(textTracks, function (i, e) {
                                    addTextTrack = $video.addTextTrack("subtitles", e.label ? e.label : e.language, e.language);
                                    addTextTrack.id = e.id;
                                    addTextTrack.mode = "hidden";
                                });
                                $.each($video.textTracks, function (i, e) {
                                    if (e.label === "Shaka Player TextTrack") {
                                        gdPlyr.mpd.startTrackValue = i;
                                        return false;
                                    }
                                });
                            }
                            gdPlyr.player = new Plyr(gdPlyr.container, gdPlyr.config);
                            gdPlyr.player.speed = 1;
                            gdPlyr.player.poster = poster;
                            gdPlyr.player.once("play", gdPlyr.events.play);
                            gdPlyr.player.once("ended", gdPlyr.events.ended);
                            gdPlyr.player.on("timeupdate", gdPlyr.events.timeupdate);
                            gdPlyr.player.on("enterfullscreen", gdPlyr.events.enterfullscreen);
                            gdPlyr.player.on("exitfullscreen", gdPlyr.events.exitfullscreen);
                            gdPlyr.player.on("ready", function (e) {
                                gdPlyr.html.loadCustomHTML();
                                gdPlyr.mpd.loadAudio();
                                $(gdPlyr.html.qualityButton).click(function () {
                                    gdPlyr.mpd.qualityChange($(this).val());
                                });
                                isLive = $(".plyr__time--duration").text() === "00:00";
                                if (isLive) {
                                    $(".plyr").addClass("plyr--live");
                                } else {
                                    $(".plyr").removeClass("plyr--live");
                                }
                                gdPlyr.mediaSession.load();
                                if (typeof reload !== "undefined") {
                                    e.detail.plyr.elements.container.classList.add("plyr--loading");
                                }
                                if (textTracks.length > 0 && gdPlyr.mpd.startTrackValue > -1) {
                                    $(".plyr__menu__container [data-plyr='language'][value='" + gdPlyr.mpd.startTrackValue + "']").hide();
                                    gdPlyr.player.currentTrack = 0;
                                    gdPlyr.shakaPlayer.selectTextTrack(textTracks[0]);
                                    gdPlyr.shakaPlayer.setTextTrackVisibility(true);
                                    gdPlyr.mpd.selectTrack(1);
                                } else {
                                    gdPlyr.html.loadExternalTracks();
                                }
                            });
                            gdPlyr.player.on("loadedmetadata", function () {
                                gdPlyr.timeChecker();
                                gdPlyr.player.currentTime = gdPlyr.hls.currentTime;
                                if (typeof reload !== "undefined") {
                                    gdPlyr.player.play();
                                }
                            });
                            gdPlyr.player.on("languagechange captionsenabled", function (e) {
                                var addedTrackSelected = -1,
                                    trackSelected = gdPlyr.player.currentTrack,
                                    shakaTrackSelected;
                                $.each($video.textTracks, function (i, e) {
                                    e.mode = "hidden";
                                });
                                if (trackSelected > -1) {
                                    if (trackSelected >= gdPlyr.mpd.startTrackValue) {
                                        if (trackSelected > gdPlyr.mpd.startTrackValue) {
                                            addedTrackSelected = gdPlyr.mpd.startTrackValue + trackSelected - 1;
                                        } else {
                                            addedTrackSelected = gdPlyr.mpd.startTrackValue;
                                        }
                                        shakaTrackSelected = textTracks[addedTrackSelected];
                                        if (typeof shakaTrackSelected !== "undefined") {
                                            gdPlyr.player.currentTrack = gdPlyr.mpd.startTrackValue;
                                            gdPlyr.shakaPlayer.selectTextTrack(shakaTrackSelected);
                                            gdPlyr.shakaPlayer.setTextTrackVisibility(true);
                                            gdPlyr.mpd.selectTrack(trackSelected);
                                        }
                                    } else {
                                        gdPlyr.player.currentTrack = trackSelected;
                                        gdPlyr.shakaPlayer.setTextTrackVisibility(false);
                                        gdPlyr.player.captions.currentTrackNode.mode = "showing";
                                        gdPlyr.mpd.selectTrack(trackSelected);
                                    }
                                } else {
                                    gdPlyr.player.currentTrack = -1;
                                    gdPlyr.shakaPlayer.setTextTrackVisibility(false);
                                }
                            });
                            gdPlyr.player.on("qualitychange", function (e) {
                                gdPlyr.mpd.qualityChange(e.detail.quality);
                            });
                            gdPlyr.shakaPlayer.addEventListener("adaptation", function () {
                                variantSelected = gdPlyr.shakaPlayer.getVariantTracks().findIndex(function (e) {
                                    return e.active;
                                });
                                gdPlyr.html.updateQualityMenuItem(variantSelected);
                            });
                        })
                        .catch(gdPlyr.mpd.errorHandler);
                }
            },
        },
        mediaSession: {
            updatePositionState: function (state) {
                if ("mediaSession" in navigator) {
                    if ("playbackState" in navigator.mediaSession) {
                        navigator.mediaSession.playbackState = state;
                    }
                    if (!isLive && "setPositionState" in navigator.mediaSession) {
                        navigator.mediaSession.setPositionState({
                            duration: gdPlyr.player.duration,
                            playbackRate: gdPlyr.player.speed,
                            position: gdPlyr.player.currentTime,
                        });
                    }
                }
            },
            load: function () {
                if ("mediaSession" in navigator) {
                    navigator.mediaSession.metadata = new MediaMetadata({
                        title: title,
                        artwork: [
                            {
                                src: poster,
                            },
                        ],
                    });
                    navigator.mediaSession.setActionHandler("play", function () {
                        gdPlyr.player.play();
                        gdPlyr.mediaSession.updatePositionState("playing");
                    });
                    navigator.mediaSession.setActionHandler("pause", function () {
                        if (isLive) {
                            gdPlyr.player.stop();
                        } else {
                            gdPlyr.player.pause();
                        }
                        gdPlyr.mediaSession.updatePositionState("paused");
                    });
                    navigator.mediaSession.setActionHandler("stop", function () {
                        gdPlyr.player.stop();
                        gdPlyr.mediaSession.updatePositionState("paused");
                    });
                    if (!isLive) {
                        navigator.mediaSession.setActionHandler("seekbackward", function () {
                            gdPlyr.player.rewind();
                            gdPlyr.mediaSession.updatePositionState("none");
                        });
                        navigator.mediaSession.setActionHandler("seekforward", function () {
                            gdPlyr.player.forward();
                            gdPlyr.mediaSession.updatePositionState("none");
                        });
                    }
                }
            },
        },
        customCSS: "<style>.plyr__captions .plyr__caption{color:" + pConf.captionsColor + "!important}.plyr--audio .plyr__control.plyr__tab-focus,.plyr--video .plyr__control.plyr__tab-focus,.plyr__control.plyr__tab-focus{box-shadow:0 0 0 5px rgba(" + pConf.rgbColor + ",.5)!important}.plyr--full-ui input[type=range].plyr__tab-focus::-webkit-slider-runnable-track{box-shadow:0 0 0 5px rgba(" + pConf.rgbColor + ",.5)!important}.plyr--full-ui input[type=range].plyr__tab-focus::-moz-range-track{box-shadow:0 0 0 5px rgba(" + pConf.rgbColor + ",.5)!important}.plyr--full-ui input[type=range].plyr__tab-focus::-ms-track{box-shadow:0 0 0 5px rgba(" + pConf.rgbColor + ",.5)!important}.plyr--audio .plyr__control.plyr__tab-focus,.plyr--audio .plyr__control:hover,.plyr--audio .plyr__control[aria-expanded=true],.plyr--video .plyr__control.plyr__tab-focus,.plyr--video .plyr__control:hover,.plyr--video .plyr__control[aria-expanded=true],.plyr__control--overlaid:focus,.plyr__control--overlaid:hover,.plyr__menu__container .plyr__control[role=menuitemradio][aria-checked=true]::before,.lds-ellipsis > div{background:" + pConf.playerColor + "!important}.plyr__control--overlaid{background:rgba(" + pConf.rgbColor + ",.8)!important}.plyr--full-ui input[type=range]{color:" + pConf.playerColor + "!important}</style>",
    };

showLoading();
sandboxDetector();
if (pConf.productionMode) {
    preventOpenDevTools();
} else {
    gdPlyr.config.debug = true;
}

if ("player" in pConf) {
    if (pConf.player.indexOf("jwplayer") > -1) {
        $("head").append(jwp.customCSS);

        if (typeof jwplayer().key === "undefined") {
            jwp.config.key = "ITWMv7t88JGzI0xPwW8I0+LveiXX9SWbfdmt0ArUSyc=";
        }

        if (pConf.enableShare) {
            jwp.config.sharing = {
                sites: ["facebook", "twitter", "pinterest", "tumblr", "linkedin", "reddit", "email"],
            };
        }

        jwp.config.skin = jwp.loadSkin();

        if (window.sandboxed) {
            showMessage("Sandboxed embed is not allowed!");
        } else {
            justDetectAdblock.detectAnyAdblocker().then(jwp.adblocker);
        }
        window.jwp = jwp;
        window.customRewind = jwp.rewind;
        window.customForward = jwp.forward;
    } else if (pConf.player.indexOf("plyr") > -1) {
        $("head").append(gdPlyr.customCSS);

        if (haveAds) {
            gdPlyr.config.ads = {
                enabled: true,
                tagUrl: pConf.vastAds.schedule[0].tag,
            };
        }

        if (pConf.showDownloadButton && pConf.enableDownloadPage) {
            gdPlyr.config.controls.push("download");
            gdPlyr.config.urls.download = pConf.downloadLink;
        }

        if (pConf.displayRateControls) {
            gdPlyr.config.settings.push("speed");
        }

        gdPlyr.config.controls.push("captions", "settings", "pip", "googlecast", "airplay", "fullscreen");

        if (window.sandboxed) {
            showMessage("Sandboxed embed is not allowed!");
        } else {
            justDetectAdblock.detectAnyAdblocker().then(gdPlyr.adblocker);
        }
        window.gdPlyr = gdPlyr;
    }
} else {
    showMessage("The video player is not recognized!");
}

if (pConf.hosts.indexOf("fembed") > -1) {
    statLogInterval = setInterval(function () {
        statCounter();
    }, 3000);
}

if (typeof document.isFullscreen === "undefined") {
    document.isFullscreen = function () {
        return !((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen));
    };
}

window.onorientationchange = function (e) {
    var vid = document.getElementsByTagName("video")[0];
    if (e.landscape) {
        if (vid.requestFullscreen) {
            vid.requestFullscreen();
        } else if (vid.mozRequestFullScreen) {
            vid.mozRequestFullScreen();
        } else if (vid.webkitRequestFullscreen) {
            vid.webkitRequestFullscreen();
        }
    }
};

$(document).ajaxSend(function (res, xhr, opt) {
    if (opt.url.indexOf(pConf.apiURL + "ajax/?action=stat") > -1) {
        if (statCounted) {
            xhr.abort();
        } else {
            statCounted = true;
        }
    }
});

function loadSources(sCallback, eCallback) {
    $.ajax({
        url: pConf.apiURL + "api/?" + pConf.apiQuery,
        type: "GET",
        dataType: "json",
        cache: false,
        timeout: 60000,
        success: sCallback,
        error: eCallback,
    });
}

function sandboxDetector() {
    window.sandboxed = false;
    try {
        if (window.frameElement.hasAttribute("sandbox")) {
            window.sandboxed = true;
        }
        return;
    } catch (t) {}
    try {
        document.domain = document.domain;
    } catch (t) {
        try {
            if (-1 != t.toString().toLowerCase().indexOf("sandbox")) {
                window.sandboxed = true;
            }
            return;
        } catch (t) {}
    }
    try {
        if (!window.navigator.plugins["namedItem"]("Chrome PDF Viewer")) return false;
    } catch (e) {
        return false;
    }
    var e = document.createElement("object");
    e.data = "data:application/pdf;base64,aG1t";
    e.style = "position:absolute;top:-500px;left:-500px;visibility:hidden;";
    e.onerror = function () {
        window.sandboxed = true;
    };
    e.onload = function () {
        e.parentNode.removeChild(e);
    };
    document.body.appendChild(e);
    setTimeout(function () {
        if (e.parentNode) {
            e.parentNode.removeChild(e);
        }
    }, 150);
}

function showMessage(msg) {
    if (msg) {
        $("#message").html(msg);
    }
    $("#mContainer, #message").show();
    $("#loading, .jwplayer, .plyr").hide();
}

function showLoading() {
    $("#message").text(pConf.message);
    $("#mContainer, #message, #loading").show();
    $(".jwplayer, .plyr").hide();
}

function showPlayer() {
    $("#mContainer").hide();
    $(".jwplayer, .plyr").show();
}

function popupBlocker(wo) {
    return (wo && typeof wo !== "undefined") || typeof window.canRunAds === "undefined" || !window.canRunAds;
}

function prettySecond(s) {
    var num = Number(s, 10),
        hrs = Math.floor(num / 3600),
        min = Math.floor((num - hrs * 3600) / 60),
        sec = num - hrs * 3600 - min * 60;
    if (hrs < 10) {
        hrs = "0" + hrs;
    }
    if (min < 10) {
        min = "0" + min;
    }
    if (sec < 10) {
        sec = "0" + sec;
    }
    return hrs + ":" + min + ":" + sec;
}

function gtagReport(event, label, category, interaction) {
    if (typeof gtag !== "undefined") {
        gtag("event", event, {
            event_label: label,
            event_category: category,
            non_interaction: interaction,
        });
    }
}

function failed() {
    showMessage('Failed to fetch video sources from server! <a href="javascript:void(0)" onclick="xStorage.clear();location.reload()">Reload Page</a>');
    gtagReport("video_error", "Failed to fetch video sources from server. Try again", "video_error", false);
}

function retry(retryNumber) {
    xStorage.setItem(retryKey, retryNumber);
    xStorage.setItem("autoplay", true);
    xStorage.removeItem("plyr");
    xStorage.removeItem("jwplayer.qualityLabel");
    $.ajax({
        url: pConf.apiURL + "ajax/?action=clear-cache&data=" + pConf.query + "&token=" + pConf.token,
        method: "GET",
        dataType: "json",
        cache: false,
        timeout: 60000,
        success: function (res) {
            location.reload();
        },
        error: function (xhr, status) {
            failed();
        },
    });
}

function preventOpenDevTools() {
    console.clear();
    var before = new Date().getTime();
    debugger;
    var after = new Date().getTime();
    if (after - before > 200) {
        $("body").text(" Dont open Developer Tools.");
        window.location.replace("https://www.google.com");
    }
    setTimeout(preventOpenDevTools, 100);
}

function adblockerMessage() {
    gtagReport("adblocker_error", "Disable AdBlocker Message", "ads", false);
    showMessage('<p><img src="' + pConf.baseURL + 'assets/img/stop-sign-hand.webp" width="100" height="100" alt="Stop AdBlocker"></p><p>Please support us by disabling AdBlocker.</p>');
}

function statCounter() {
    $.ajax({
        url: pConf.apiURL + "ajax/?action=stat&data=" + pConf.query + "&token=" + pConf.token,
        method: "GET",
        dataType: "json",
        cache: false,
        timeout: 60000,
    });
}

function visitDirectAds() {
    if (!pConf.disableDirectAds && pConf.visitAdsOnplay && pConf.directAdsLink !== "" && pConf.directAdsLink !== "#") {
        var wo = window.open(pConf.directAdsLink, "_blank");
        setTimeout(function () {
            if (popupBlocker(wo)) {
                $("#iframeAds").attr("src", pConf.directAdsLink);
                $("#directAds").show();
            }
        }, 3000);
    }
}

$(document).on("contextmenu", function (e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
});

if (pConf.pauseOnLeft) {
    var hidden, visibilityChange;
    if (typeof document.hidden !== "undefined") {
        hidden = "hidden";
        visibilityChange = "visibilitychange";
    } else if (typeof document.msHidden !== "undefined") {
        hidden = "msHidden";
        visibilityChange = "msvisibilitychange";
    } else if (typeof document.webkitHidden !== "undefined") {
        hidden = "webkitHidden";
        visibilityChange = "webkitvisibilitychange";
    }

    if (typeof document.addEventListener !== "undefined" && typeof hidden !== "undefined") {
        document.addEventListener(
            visibilityChange,
            function () {
                if (document[hidden]) {
                    if (jwp.player && jwp.player.getState() === "playing") {
                        jwp.player.pause();
                    } else if (gdPlyr.player && gdPlyr.player.playing) {
                        gdPlyr.player.pause();
                    }
                }
            },
            false
        );
    }
}
