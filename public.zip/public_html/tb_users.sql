-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 5.7.24 - MySQL Community Server (GPL)
-- OS Server:                    Win64
-- HeidiSQL Versi:               10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- membuang struktur untuk table db_videoplayer.tb_users
DROP TABLE IF EXISTS `tb_users`;
CREATE TABLE `tb_users` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`user` VARCHAR(50) NOT NULL,
	`email` VARCHAR(100) NOT NULL,
	`password` VARCHAR(500) NOT NULL,
	`name` VARCHAR(50) NOT NULL,
	`status` INT(11) NOT NULL,
	`added` INT(11) NOT NULL,
	`updated` INT(15) NOT NULL DEFAULT '0',
	`role` INT(11) NOT NULL,
	PRIMARY KEY (`id`),
	UNIQUE INDEX `user` (`user`),
	UNIQUE INDEX `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Membuang data untuk tabel db_videoplayer.tb_users: ~2 rows (lebih kurang)
/*!40000 ALTER TABLE `tb_users` DISABLE KEYS */;
REPLACE INTO `tb_users` (`id`, `user`, `email`, `password`, `name`, `status`, `added`, `updated`, `role`) VALUES
	(1, 'admin', 'admin@gdplayer.top', '$2y$10$NINj/fIn5uU/k7nZqcpubux7hMyA9FXxV7sfFmplu1oEgduKHp0Ty', 'Admin', 1, 0, 1642938985, 0),
	(2, 'demo', 'demo@gdplayer.top', '$2y$10$CmeA6fPZckFBp2pnZlpPIOs8KSFxAC.BQtjImAPBTBu6m4D.qfWzm', 'Demo', 1, 0, 1630917289, 1);
/*!40000 ALTER TABLE `tb_users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
