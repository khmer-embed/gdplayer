<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto lspJ0MUf2i5B5_A; s255uCZ6CYuWfdo: $class = new \GDPlayer\Ajax\Videos(); goto uGqA0DxMBlshaRV; lspJ0MUf2i5B5_A: session_write_close(); goto s255uCZ6CYuWfdo; uGqA0DxMBlshaRV: echo $class->response($_POST, $_FILES);
