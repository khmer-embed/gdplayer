<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto RkMYTCE1wjxd4m5; k8hNfmH0LGL1m54: $class = new \GDPlayer\Ajax\Videos(); goto WuyUU36kg8XgMh8; RkMYTCE1wjxd4m5: session_write_close(); goto k8hNfmH0LGL1m54; WuyUU36kg8XgMh8: echo $class->list($_GET);
