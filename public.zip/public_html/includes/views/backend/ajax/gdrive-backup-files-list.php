<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto xscLQuesN7NhWkV; Wa9dPAJmsJ1ALSs: $class = new \GDPlayer\Ajax\GDriveMirrors(); goto YInTBVog8AktbUU; xscLQuesN7NhWkV: session_write_close(); goto Wa9dPAJmsJ1ALSs; YInTBVog8AktbUU: echo $class->list($_GET);
