<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto OMC4vkcEehVs0mf; OMC4vkcEehVs0mf: session_write_close(); goto NHPapMA3XJ5fnIn; NHPapMA3XJ5fnIn: $class = new \GDPlayer\Ajax\GDriveFiles(); goto ZMqYCtrHoCDKu2e; ZMqYCtrHoCDKu2e: echo $class->response($_POST);
