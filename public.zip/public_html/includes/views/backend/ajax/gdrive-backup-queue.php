<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ZapFMY1pU99DGGv; MaVPAa1xUrW632_: $class = new \GDPlayer\Ajax\GDriveQueue(); goto s4CAN6qhbIcoAkQ; ZapFMY1pU99DGGv: session_write_close(); goto MaVPAa1xUrW632_; s4CAN6qhbIcoAkQ: echo $class->response($_POST);
