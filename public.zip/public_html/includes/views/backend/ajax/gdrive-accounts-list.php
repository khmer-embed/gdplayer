<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Jhcl8JTQu42CVPI; Jhcl8JTQu42CVPI: session_write_close(); goto QUmG9rA8Cp2lTEw; QUmG9rA8Cp2lTEw: $class = new \GDPlayer\Ajax\GDriveAccounts(); goto B37BjomFJhlsLAH; B37BjomFJhlsLAH: echo $class->list($_GET);
