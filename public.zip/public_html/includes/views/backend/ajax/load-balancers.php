<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto OiqrbCGJ5PJVv0I; kcO6_31RkMQFaiz: $class = new \GDPlayer\Ajax\LoadBalancers(); goto sJzzFYa7URwg4nP; OiqrbCGJ5PJVv0I: session_write_close(); goto kcO6_31RkMQFaiz; sJzzFYa7URwg4nP: echo $class->response($_POST);
