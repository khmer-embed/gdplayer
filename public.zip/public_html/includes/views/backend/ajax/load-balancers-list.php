<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto GCog9wZy3PEfqjJ; nXJn2CF0Sz9B6IF: $class = new \GDPlayer\Ajax\LoadBalancers(); goto wX5eU0ggwyYSeQX; GCog9wZy3PEfqjJ: session_write_close(); goto nXJn2CF0Sz9B6IF; wX5eU0ggwyYSeQX: echo $class->list($_GET);
