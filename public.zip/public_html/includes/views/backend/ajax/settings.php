<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto gzJf1uECmAlnUA5; gzJf1uECmAlnUA5: session_write_close(); goto Xdzrn_PtOr9_72J; Xdzrn_PtOr9_72J: $class = new \GDPlayer\Ajax\Settings(); goto egR5Yn4_MJzx4PN; egR5Yn4_MJzx4PN: echo $class->response($_POST);
