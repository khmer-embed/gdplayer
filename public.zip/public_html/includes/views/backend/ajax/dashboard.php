<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto pPxZkjhisbx6Rch; o4eEIjuSiFdPHe2: ini_set("\x6d\141\x78\x5f\x65\x78\145\x63\165\164\151\x6f\156\x5f\x74\151\x6d\145", -1); goto E79CReYJp94xz7C; pPxZkjhisbx6Rch: session_write_close(); goto o4eEIjuSiFdPHe2; E79CReYJp94xz7C: $class = new \GDPlayer\Ajax\Dashboard(); goto KnwfmJxsi_L01gS; KnwfmJxsi_L01gS: echo $class->response($_POST);
