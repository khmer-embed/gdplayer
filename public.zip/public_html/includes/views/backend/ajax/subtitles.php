<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto r6eR6XSbfP157Mh; ZNFXh4BJxuYSflg: $class = new \GDPlayer\Ajax\Subtitles(); goto eXswFJgAw1bT_S5; r6eR6XSbfP157Mh: session_write_close(); goto ZNFXh4BJxuYSflg; eXswFJgAw1bT_S5: echo $class->response($_POST, $_FILES);
