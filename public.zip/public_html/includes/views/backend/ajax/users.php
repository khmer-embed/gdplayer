<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto fi6eCW30YgcLTR7; r_WWzTyAWZ2kH_8: $class = new \GDPlayer\Ajax\Users(); goto uVMt5I0Niratt9Z; fi6eCW30YgcLTR7: session_write_close(); goto r_WWzTyAWZ2kH_8; uVMt5I0Niratt9Z: echo $class->response($_POST);
