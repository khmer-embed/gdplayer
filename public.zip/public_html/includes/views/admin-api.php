<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto t8mPOWP5s7dPapD; c2Bg2Oav0sFD5iN: echo $class->response($_POST); goto TLGxpWEd9BQc5Ok; Qn4JBbp_Za1iKoW: if (isset($_POST["\x61\143\x74\x69\157\156"])) { goto VOfnCZh8FVUsOSG; } goto JDAQQz7qHPXjik1; r9JFk8OKgQlUVlZ: if (defined("\x42\101\123\x45\137\x44\111\122")) { goto FbmJcIrdnZOiMWD; } goto FU4ANlXhPCRfh0y; JDAQQz7qHPXjik1: session_write_close(); goto O0yGRq9ofNotv9t; GcjP3wBuU10lqsv: $class = new \GDPlayer\Ajax\PrivateAjax(); goto Qn4JBbp_Za1iKoW; k2SF8Munn_JZuvV: VOfnCZh8FVUsOSG: goto M8ExMtWUMIEPj52; t8mPOWP5s7dPapD: session_write_close(); goto r9JFk8OKgQlUVlZ; FU4ANlXhPCRfh0y: session_write_close(); goto Dq1geOlwkBGjdiq; VZrze931Q7GN2iF: header("\x43\x61\x63\x68\145\55\103\157\156\164\162\157\154\x3a\40\x6e\157\x2d\x63\141\x63\x68\145\54\40\x6d\x61\170\55\x61\147\x65\x3d\x30"); goto HVNu_wWpP2grlyx; HVNu_wWpP2grlyx: disableCorsPolicy(); goto GcjP3wBuU10lqsv; O0yGRq9ofNotv9t: echo $class->notValid(); goto IRYMqul6iS7K3Cv; M8ExMtWUMIEPj52: session_write_close(); goto c2Bg2Oav0sFD5iN; Dq1geOlwkBGjdiq: exit("\x41\x63\x63\x65\163\x73\40\x64\145\156\151\x65\144"); goto pmgMhT8o1qFctFp; pmgMhT8o1qFctFp: FbmJcIrdnZOiMWD: goto VZrze931Q7GN2iF; IRYMqul6iS7K3Cv: goto WT_JgSzHBe0fFA5; goto k2SF8Munn_JZuvV; TLGxpWEd9BQc5Ok: WT_JgSzHBe0fFA5:
