<?php

/**
 * Insert your website homepage url. Example: https://yoursite.com/ (slash at the end)
 */
define('BASE_URL', 'http://localhost/gdplayer/');

/**
 * Insert random alphanumeric as security code to encrypt/decrypt the existing string on your site
 */
define('SECURE_SALT', 'kBdx-');

/**
 * Backend url path
 */
define('ADMIN_DIR', 'backend');

/**
 * Backend theme folder name
 */
define('BACKEND_THEME', 'default');

/**
 * Frontend theme folder name
 */
define('FRONTEND_THEME', 'default');

/**
 * The absolute path directory where this tool installed. Don't Change the value
 */
define('BASE_DIR', dirname(__FILE__, 2) . '/');

/**
 * User agent makes this tool appear accessible to humans, not robots
 */
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36');

/**
 * Database MySQL Connection Settings
 */
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'db_test');
define('DB_PORT', 3306);
define('DB_ATTR_PERSISTENT', true);

/**
 * Redis Connection Settings
 */
define('REDIS_HOST', '127.0.0.1');
define('REDIS_PORT', 6379);
define('REDIS_DATABASE', 16);
define('REDIS_PASSWORD', '');
