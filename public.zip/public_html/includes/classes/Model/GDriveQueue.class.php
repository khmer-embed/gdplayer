<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveQueue extends \GDPlayer\Model { protected $table = "\164\x62\137\147\x64\162\151\166\145\x5f\x71\165\x65\x75\145"; protected $fields = ["\151\144", "\x67\x64\x72\151\166\x65\137\151\144", "\144\145\x6c\x61\171\145\x64"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
