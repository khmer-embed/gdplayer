<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideoSources extends \GDPlayer\Model { protected $table = "\x74\142\137\166\x69\144\x65\157\163\x5f\163\x6f\x75\x72\x63\145\163"; protected $fields = ["\151\144", "\150\157\163\164", "\x68\x6f\x73\164\x5f\x69\x64", "\144\x61\x74\141", "\x64\154", "\x73\151\x64", "\143\x72\145\x61\x74\x65\144", "\x65\x78\x70\151\x72\145\x64"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
