<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveMirrors extends \GDPlayer\Model { protected $table = "\164\142\x5f\x67\x64\x72\151\166\145\x5f\x6d\x69\162\x72\x6f\162\x73"; protected $fields = ["\x69\x64", "\147\144\x72\151\x76\145\137\x69\144", "\x6d\151\x72\x72\157\162\x5f\x69\144", "\155\x69\162\x72\x6f\x72\x5f\145\x6d\x61\151\154", "\141\x64\144\x65\x64"]; protected $primaryKey = "\x69\144"; protected $gdAPI; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
