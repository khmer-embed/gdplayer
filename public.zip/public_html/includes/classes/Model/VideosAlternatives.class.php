<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideosAlternatives extends \GDPlayer\Model { protected $table = "\x74\142\137\166\151\x64\145\157\x73\x5f\141\154\164\145\162\x6e\141\164\x69\x76\145\x73"; protected $fields = ["\x69\144", "\x76\x69\x64", "\x68\157\x73\164", "\150\x6f\163\x74\137\151\x64", "\x6f\162\144\145\162"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
