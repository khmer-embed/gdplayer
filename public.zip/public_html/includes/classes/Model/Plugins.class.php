<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Plugins extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\160\154\165\x67\x69\x6e\163"; protected $fields = ["\x69\x64", "\x6b\x65\x79", "\166\141\154\x75\145", "\165\x70\x64\141\164\145\x64"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
