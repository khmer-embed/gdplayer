<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideosHash extends \GDPlayer\Model { protected $table = "\164\x62\x5f\x76\x69\144\145\x6f\163\137\x68\x61\163\x68"; protected $fields = ["\151\144", "\x68\157\163\x74", "\x68\157\163\164\x5f\x69\x64", "\147\x64\x72\151\166\145\137\x65\x6d\141\151\154", "\144\x61\x74\141"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
