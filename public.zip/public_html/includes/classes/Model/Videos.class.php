<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Videos extends \GDPlayer\Model { protected $table = "\164\142\137\166\151\x64\x65\157\163"; protected $fields = ["\x69\144", "\164\x69\x74\x6c\x65", "\x68\157\x73\164", "\x68\x6f\x73\164\137\x69\144", "\x75\x69\x64", "\141\144\x64\x65\x64", "\165\160\x64\141\164\x65\144", "\160\x6f\163\164\x65\162", "\x73\164\141\x74\x75\163", "\166\x69\x65\x77\x73", "\x64\155\143\141"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
