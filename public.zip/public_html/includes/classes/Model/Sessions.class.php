<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Sessions extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\x73\x65\163\x73\151\x6f\156\x73"; protected $fields = ["\x69\x64", "\151\x70", "\165\163\x65\162\141\147\x65\156\164", "\x63\x72\145\x61\164\x65\144", "\165\x73\x65\162\156\141\155\x65", "\x65\170\160\151\x72\x65\x64", "\x74\157\153\x65\156", "\163\164\141\x74"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
