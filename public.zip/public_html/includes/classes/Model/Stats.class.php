<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Stats extends \GDPlayer\Model { protected $table = "\164\x62\137\x73\164\141\x74\x73"; protected $fields = ["\151\x64", "\166\151\x64", "\x69\x70", "\x75\141", "\143\x72\x65\x61\164\145\144"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
