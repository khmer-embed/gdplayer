<?php
session_write_close();
header('location: ' . strtr($_SERVER['REQUEST_URI'], ['embed2.php' => 'embed2/']) . '?' . $_SERVER['QUERY_STRING']);
