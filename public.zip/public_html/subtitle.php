<?php
session_write_close();
header('location: ' . strtr($_SERVER['REQUEST_URI'], ['subtitle.php' => 'subtitle.vtt']) . '?' . $_SERVER['QUERY_STRING']);
